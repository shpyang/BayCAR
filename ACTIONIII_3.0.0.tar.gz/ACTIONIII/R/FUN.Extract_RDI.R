FUN.Extract_RDI <- function(api_url, api_token) {     # FIXED: explicit credentials (no globals)
  rfields <- c("record_id","random_age","random_chemo_duration","random_fluoropyrimidine",
               "random_chemo_started","random_date","random_group","sex","age","dob")
  efields <- c("record_id","ipd_status")
  sfields <- c("record_id","spc_o_cyc","spc_o_cyclength","spc_o_dose",
               "spc_f_bolus_cyc","spc_f_bolus_cyclength","spc_f_bolus_dose",
               "spc_f_cont_cyc","spc_f_cont_cyclength","spc_f_cont_dose",
               "spc_c_cyc","spc_c_cyclength","spc_c_dose","spc_chemo_regimen",
               "planned_chemotherapy_schedule_complete",
               "spc_cyc_a1","spc_cyclength_a1","spc_dose_a1",
               "spc_cyc_a2","spc_cyclength_a2","spc_dose_a2",
               "spc_cyc_a3","spc_cyclength_a3","spc_dose_a3",
               "spc_chemo_regimen___1","spc_chemo_regimen___2","spc_chemo_regimen___3")
  cfields <- c("record_id","chemo_bl_doseadmin_o","chemo_bl_doseadmin_f_bolus",
               "chemo_bl_doseadmin_f_cont","chemo_bl_doseadmin_c","chemo_bl_doseadmin_a1",
               "chemo_bl_date","chemotherapy_baseline_complete",
               "chemo_bl_doseadmin_a1_plan","chemo_bl_doseadmin_a2_plan","chemo_bl_doseadmin_a3_plan")
  mfields <- c("record_id","chemo_doseadmin_o","chemo_doseadmin_f_bolus","chemo_doseadmin_f_cont",
               "chemo_doseadmin_c","chemo_date","chemo_cyc","chemotherapy_complete",
               "chemo_doseadmin_a1","chemo_doseadmin_a1_plan","chemo_doseadmin_a2_plan",
               "chemo_doseadmin_a3_plan","bl_earlyterm","bl_earlyterm_tox_reason___1",
               "bl_earlyterm_tox_reason___5","bl_earlyterm_tox_reason___2",
               "bl_earlyterm_tox_reason___99","bl_earlyterm_tox_reason_o")
  
  message("Extracting schedule data...");   sc  <- FUN.schedule(api_url, api_token, rfields, sfields)
  message("Extracting cycle 1 data...");    cy1 <- FUN.cyc1(api_url, api_token, rfields, cfields)
  message("Extracting all cycles data..."); cm  <- FUN.cm(api_url, api_token, rfields, mfields)
  
  MMMM <- FUN.MMM(api_url, api_token, rfields, sc, cy1, cm)
  
  ## documented manual corrections
  MMMM$cyc.OX[MMMM$record_id=="S05-02-0056"] <- 0    # CAP-only patient (falls through to cyc.CAP below)
  MMMM$cyc.OX[MMMM$record_id=="S05-02-0025"] <- 6
  
  ## FIXED: zeros treated as "not planned" so coalesce falls through correctly
  MMMM$cyc.fill <- dplyr::coalesce(dplyr::na_if(MMMM$cyc.OX,0), dplyr::na_if(MMMM$cyc.CAP,0),
                                   dplyr::na_if(MMMM$cyc.FU,0),  dplyr::na_if(MMMM$cyc.FUc,0))
  MMMM$filladm  <- dplyr::coalesce(MMMM$OXadm, MMMM$CAPadm, MMMM$FUadm, MMMM$FUcadm)
  MMMM$day.fill <- dplyr::coalesce(dplyr::na_if(MMMM$day.OX,0), dplyr::na_if(MMMM$day.CAP,0),
                                   dplyr::na_if(MMMM$day.FU,0),  dplyr::na_if(MMMM$day.FUc,0))
  
  MMM <- FUN.fill_missing_cycles_base(MMMM, "cyc.fill", "filladm", "day.fill")  # FIXED: "day.full" typo
  
  ## documented zero-dose patches
  MMM$OXadm[is.na(MMM$OXadm)  & MMM$record_id=="S05-01-0050"] <- 0
  MMM$FUadm[is.na(MMM$FUadm)  & MMM$record_id=="S05-01-0050"] <- 0
  MMM$FUcadm[is.na(MMM$FUcadm)& MMM$record_id=="S05-01-0050"] <- 0
  MMM$CAPadm[is.na(MMM$CAPadm)& MMM$record_id=="S05-01-0003"] <- 0
  
  RDIs <- FUN.RDI.table(MMM)
  
  EOS <- as.data.frame(REDCapR::redcap_read(batch_size=300, redcap_uri=api_url,
                                            token=api_token, fields=efields, verbose=FALSE)$data)
  EOS <- EOS[!is.na(EOS$ipd_status) & EOS$ipd_status%in%c("C", "NS"), ]   # adaptation uses completers only (documented)
  EOS <- EOS[EOS$record_id != "S05-02-0016", ]                # withdrew (also S05-02-0012, S05-02-0015)
  
  CRDIs   <- RDIs[RDIs$record_id %in% sort(unique(EOS$record_id)), ]
  outRDI  <- CRDIs[, c("record_id","random_group","RDI")]
  list(outRDI, CRDIs, MMM)
}