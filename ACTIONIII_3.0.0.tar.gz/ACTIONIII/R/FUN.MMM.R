FUN.MMM <- function(api_url, api_token, rfields, sc, cy1, cm) {
  rd <- FUN.rd(api_url, api_token, rfields)
  
  cy1$complete... <- 2
  cy1$Date.chemo  <- cy1$Date.cy1
  cy1 <- cy1[, names(cy1) != "Date.cy1", drop=FALSE]
  cy1$Current.Cycle.Number <- 1
  cm$complete.. <- 2
  cm$Date.chemo <- cm$Date.cm
  cm <- cm[, names(cm) != "Date.cm", drop=FALSE]
  cm <- cm[!is.na(cm$Current.Cycle.Number) & cm$Current.Cycle.Number > 1, ]   # FIXED: NA cycles no longer become all-NA rows
  
  cmm <- rbind(cy1, cm[, intersect(names(cm), names(cy1)), drop=FALSE])        # FIXED: dead -which() rbind removed
  cmm$Date.chemo <- as.Date(cmm$Date.chemo, tryFormats=c("%Y-%m-%d","%m/%d/%Y"))  # FIXED: single robust parse
  cmm <- cmm[order(cmm$record_id, cmm$Current.Cycle.Number), ]
  cmm2 <- cmm[order(cmm$record_id, cmm$Date.chemo), ]
  if (any(cmm$Current.Cycle.Number != cmm2$Current.Cycle.Number))
    warning("FUN.MMM: some patients have cycle numbers out of date order; check chemo_cyc.")
  
  MMM <- merge(sc, cmm, by="record_id", all=TRUE)
  MMM <- MMM[MMM$record_id %in% rd$record_id, ]   # 4-subject hard exclusion removed 2026-07-05 (documented)
  
  ## documented manual corrections
  MMM$FUadm[MMM$record_id=="S05-02-0027" & MMM$Current.Cycle.Number==2] <- 400
  MMM$dose.FU[MMM$record_id=="S05-02-0027"] <- 400
  MMM$CAPadm[MMM$record_id=="A00-01-3011" & MMM$Current.Cycle.Number==2] <- 2000
  MMM$dose.CAP[MMM$record_id=="A00-01-3011"] <- 2000
  MMM$CAPadm[MMM$record_id=="S05-01-0030" & MMM$Current.Cycle.Number %in% c(6,7,8)] <- 3000/1.8
  MMM$cyc.CAP[MMM$record_id=="A00-09-3322"] <- 8     # FIXED: was 11 then 8 five times
  MMM$day.CAP[MMM$record_id=="A00-09-3322"] <- 14
  MMM$dose.CAP[MMM$record_id=="A00-09-3322"] <- 2400
  
  MMM <- merge(MMM, rd[, c("record_id","sex","age","rDate","random_group","dur",
                           "random_fluoropyrimidine","random_chemo_started")],
               by="record_id", all.x=TRUE)
  MMM <- MMM[!is.na(MMM$record_id) & !is.na(MMM$Date.chemo), ]
  MMM <- MMM[order(MMM$record_id, MMM$Date.chemo), ]
  
  ## planned dose := first administered dose on/after randomization
  for (id in unique(MMM$record_id)) {
    sub <- MMM[MMM$record_id == id, ]
    k <- which(sub$Date.chemo >= sub$rDate)[1]
    if (!is.na(k)) {
      MMM[MMM$record_id == id, "dose.OX"]  <- sub$OXadm[k]
      MMM[MMM$record_id == id, "dose.FU"]  <- sub$FUadm[k]
      MMM[MMM$record_id == id, "dose.FUc"] <- sub$FUcadm[k]
      MMM[MMM$record_id == id, "dose.CAP"] <- sub$CAPadm[k]
    }
  }
  
  ## keep cycles up to the planned count; FIXED: outk reset every patient
  ## (previously a patient failing all branches re-used the previous patient's rows)
  MMMs <- MMM[0, ]
  dropped <- character(0)
  for (id in unique(MMM$record_id)) {
    sub <- MMM[MMM$record_id == id, ]
    lim <- NA
    for (cc in c("cyc.OX","cyc.FU","cyc.FUc","cyc.CAP")) {
      if (all(!is.na(sub[[cc]]))) { lim <- sub[[cc]][1]; break }
    }
    if (is.na(lim)) { dropped <- c(dropped, id); next }
    MMMs <- rbind(MMMs, sub[sub$Current.Cycle.Number <= lim, ])
  }
  if (length(dropped)) warning("FUN.MMM: no complete cycle plan for: ", paste(dropped, collapse=", "))
  MMMs[order(MMMs$record_id, MMMs$Date.chemo), ]
}

FUN.fill_missing_cycles_base <- function(data, cycle_col="cyc.fill",
                                         adm_col="filladm", days_col="day.fill") {
  split_data <- split(data, data$record_id)
  out_list <- list()
  for (id in names(split_data)) {
    sub <- split_data[[id]]
    planned <- sub[1, cycle_col]; daylen <- sub[1, days_col]
    if (is.na(planned) || planned <= 0 || is.na(daylen)) { out_list[[id]] <- sub; next }   # FIXED: was if(NA) crash
    if (planned != round(planned)) warning("Non-integer planned cycles for ", id)
    max_cycle <- as.integer(planned)
    existing  <- sub$Current.Cycle.Number
    missing_cycles <- setdiff(1:max_cycle, existing)
    if (length(missing_cycles) == 0) { out_list[[id]] <- sub; next }
    
    keep_cols <- intersect(c("record_id","random_group",                     # FIXED: random_group kept on filled rows
                             "cyc.OX","day.OX","dose.OX","cyc.FU","day.FU","dose.FU",
                             "cyc.FUc","day.FUc","dose.FUc","cyc.CAP","day.CAP","dose.CAP",
                             "cyc.fill","filladm","day.fill","regimen","rDate"), names(sub))
    diff_cols <- setdiff(names(sub), keep_cols)
    
    df1 <- sub[rep(1, max_cycle), keep_cols]; df1$Current.Cycle.Number <- 1:max_cycle
    df2 <- sub[, diff_cols, drop=FALSE]
    mg  <- merge(df1, df2, by="Current.Cycle.Number", all=TRUE)
    if (anyDuplicated(mg$Current.Cycle.Number)) {
      warning("Duplicate cycle numbers for ", id, "; no gap-fill applied.")
      out_list[[id]] <- sub; next
    }
    mg <- mg[order(mg$Current.Cycle.Number), ]
    
    ## zero-fill missing cycles only if the whole planned course should have elapsed
    d1 <- mg$Date.chemo[which(!is.na(mg$Date.chemo))[1]]                     # FIXED: not df2$Date.chemo[1]
    if (!is.na(d1) && as.numeric(Sys.Date() - d1) > planned * daylen) {      # FIXED: unified cyc.fill x day.fill gate
      for (dc in intersect(c("OXadm","FUadm","FUcadm","CAPadm"), names(mg)))
        if (!all(is.na(mg[[dc]]))) mg[mg$Current.Cycle.Number %in% missing_cycles, dc] <- 0
    }
    for (cn in intersect(c("complete.","complete..","complete..."), names(mg))) mg[, cn] <- 2
    mcyc <- suppressWarnings(max(existing, na.rm=TRUE))
    if (is.finite(mcyc) && mcyc < nrow(mg) && !is.na(mg$Date.chemo[mcyc]))   # FIXED: format-free date math
      mg$Date.chemo[(mcyc+1):nrow(mg)] <- mg$Date.chemo[mcyc] + daylen * (1:(nrow(mg)-mcyc))
    out_list[[id]] <- mg
  }
  res <- do.call(rbind, out_list); rownames(res) <- NULL; res
}
