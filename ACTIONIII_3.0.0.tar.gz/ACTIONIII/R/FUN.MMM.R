#' Create Master Chemotherapy Data Frame (MMM)
#'
#' Merges planned treatment schedules with actual administration records and
#' baseline cycle data. It aligns doses to the correct randomization dates
#' to ensure chronological accuracy.
#'
#' @param api_url Character; REDCap API endpoint.
#' @param api_token Character; REDCap API token.
#' @param rfields Fields for randomization data.
#' @param sc Data frame containing treatment schedules (from FUN.schedule).
#' @param cy1 Data frame containing baseline cycle data (from FUN.cyc1).
#' @param cm Data frame containing administration records (from FUN.cm).
#'
#' @return A consolidated longitudinal data frame sorted by record_id and date.
#' @export
#'
#'
FUN.MMM=function(api_url, api_token, rfields, sc, cy1, cm)
{
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  rraann= redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(rfields), verbose=FALSE)
  rraa=as.data.frame(rraann$data)

  rraa=rraa[!rraa$record_id%in%c("S05-01-TEST", "S05-02-TEST", "S05-03-TEST", "A00-00-TEST", "S05-01-TEST"),]
  rraa$rDate=as.Date(rraa$random_date)
  rraa1=rraa[substr(toupper(rraa$redcap_event_name ),1,3)=="PPT", c(1,5,6,7)]
  #  rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,9:14)]
  rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,8:13)]
  rraa2=rraa2[!is.na(rraa2$random_group),]

  rd=merge(rraa1, rraa2, by="record_id", all.y=TRUE)
  rd$dur=rd$random_chemo_duration
  #rd$rage=floor((rd$random_date-rd$dob)/365.25)
  #rd$age=rd$rage
  rd=rd[, -which(names(rd)%in%c("rage", "random_date"))]
  #rd$agee= round(as.Date(rd$rDate)-as.Date(rd$dob))/365.25

  rd=rd[!is.na(rd$rDate),]
######################################## cm FOLFOX CAP ########################################
######################################## cm FOLFOX CAP ########################################
######################################## cm FOLFOX CAP ########################################

  cy1$complete...=2
  cy1$Date.chemo=cy1$Date.cy1
  cy1=cy1[,-which(names(cy1)=="Date.cy1")]
  cy1$Current.Cycle.Number=1
  cm$complete..=2
  cm$Date.chemo=cm$Date.cm
  cm=cm[,-which(names(cm)=="Date.cm")]
  cm=cm[cm$Current.Cycle.Number>1,]


  cmm=rbind(cy1, cm[, - which(colnames(cm)%in%c("chemo_same_plan", "chemo_same_bl", "chemo_same_prev"))])
  cmm=rbind(cy1, cm[, which(names(cm)%in%names(cy1))] )

  cmm=cmm[order(cmm$record_id, cmm$Current.Cycle.Number),]

  cmm2=cmm[order(cmm$record_id, as.Date(cmm$Date.chemo)),]
  cmm[(cmm$Current.Cycle.Number!=cmm2$Current.Cycle.Number),]


######################################## rd + sc + cy1 ########################################
######################################## rd + sc + cy1 ########################################
######################################## rd + sc + cy1 ########################################

  MMM=merge(sc, cmm, by="record_id", all=TRUE)

  MMM=MMM[MMM$record_id%in%rd$record_id,]

  MMMx=MMM[ MMM$record_id%in%c("S05-01-0050", "S05-04-0001", "S05-04-0002", "S05-04-0004"),]


  MMM$FUadm[MMM$record_id=="S05-02-0027"&MMM$Current.Cycle.Number==2]=400
  MMM$dose.FU[MMM$record_id=="S05-02-0027"]=400

  MMM$CAPadm[MMM$record_id=="A00-01-3011"&MMM$Current.Cycle.Number==2]=2000
  MMM$dose.CAP[MMM$record_id=="A00-01-3011"]=2000

  MMM$CAPadm[MMM$record_id=="S05-01-0030"&MMM$Current.Cycle.Number%in%c(6, 7, 8)]=3000/1.8

  MMM$cyc.CAP[MMM$record_id=="A00-09-3322"]=11


  MMM$cyc.CAP[MMM$record_id=="A00-09-3322"]=8
  MMM$cyc.CAP[MMM$record_id=="A00-09-3322"]=8
  MMM$cyc.CAP[MMM$record_id=="A00-09-3322"]=8
  MMM$cyc.CAP[MMM$record_id=="A00-09-3322"]=8
  MMM$cyc.CAP[MMM$record_id=="A00-09-3322"]=8

  MMM$day.CAP[MMM$record_id=="A00-09-3322"]=14
  MMM$dose.CAP[MMM$record_id=="A00-09-3322"]=2400

  MMM=merge(MMM, rd[, c("record_id", "sex", "age", "rDate", "random_group", "dur", "random_fluoropyrimidine", "random_chemo_started")], by="record_id", all.x=TRUE)
  MMM=MMM[order(MMM$record_id, as.Date(MMM$Date.chemo )),]

MMM=MMM[!is.na(MMM$record_id),]
MMM=MMM[!is.na(MMM$Date.chemo),]

# These are very new participants
MMMxx=MMM[is.na(MMM$Date.chemo),]


# Make sure Date columns are Date type
MMM$Date.chemo <- as.Date(MMM$Date.chemo, format = "%m/%d/%Y")
MMM$rDate <- as.Date(MMM$rDate, format = "%m/%d/%Y")

# Get all unique record_ids
unique_ids <- unique(MMM$record_id)

# Loop over each record_id
for (id in unique_ids) {
  # Subset the data for this record_id
  sub_df <- MMM[MMM$record_id == id, ]

  # Find first row where Date.chemo > rDate
  rowi_index <- which(sub_df$Date.chemo >= sub_df$rDate)[1]

  # If such a row exists
  if (!is.na(rowi_index)) {
    rowi <- sub_df[rowi_index, ]

    # Replace dose values in all rows of this record_id group
    MMM[MMM$record_id == id, "dose.OX"]  <- rowi$OXadm
    MMM[MMM$record_id == id, "dose.FU"]  <- rowi$FUadm
    MMM[MMM$record_id == id, "dose.FUc"] <- rowi$FUcadm
    MMM[MMM$record_id == id, "dose.CAP"] <- rowi$CAPadm
  }
}

# Loop over each record_id
for (i in 1:length(unique_ids)) {
  # Subset the data for this record_id
  sub_df <- MMM[MMM$record_id == unique_ids[i] & (!is.na(MMM$Date.chemo)), ]

  # take into account of missing cyc.OX subjects
  # the goal is to keep those cycles after randomization
  if (all(!is.na(sub_df$cyc.OX))) {outk=sub_df[sub_df$Current.Cycle.Number<=sub_df$cyc.OX,]; pp=(sub_df[sub_df$Current.Cycle.Number>sub_df$cyc.OX,]); if (nrow(pp)>0) {#print("cycle>cyc.OX"); print(pp)
    }} else
    if (all(!is.na(sub_df$cyc.FUc))) {outk=sub_df[sub_df$Current.Cycle.Number<=sub_df$cyc.FUc,]; pp=(sub_df[sub_df$Current.Cycle.Number>sub_df$cyc.FUc,]); if (nrow(pp)>0) {#print("cycle>cyc.FUc"); print(pp)
      }} else
      if (all(!is.na(sub_df$cyc.CAP))) {outk=sub_df[sub_df$Current.Cycle.Number<=sub_df$cyc.CAP,]; pp=(sub_df[sub_df$Current.Cycle.Number>sub_df$cyc.CAP,]); if (nrow(pp)>0) {#print("cycle>cyc.CAP"); print(pp)
        }}

  if (i==1) {MMMs=outk} else
  {if ( nrow(outk)>0) {MMMs=rbind(MMMs, outk)}
  }
}

MMM=MMMs

MMM=MMM[order(MMM$record_id, as.Date(MMM$Date.chemo, format = "%m/%d/%Y")),]

return(MMM)
}
