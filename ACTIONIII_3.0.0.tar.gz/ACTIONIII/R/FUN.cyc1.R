FUN.cyc1 <- function(api_url, api_token, rfields, cfields) {
  rd  <- FUN.rd(api_url, api_token, rfields)
  cy1 <- as.data.frame(REDCapR::redcap_read(batch_size=300, redcap_uri=api_url,
                                            token=api_token, fields=cfields, verbose=FALSE)$data)
  cy1 <- cy1[substr(cy1$redcap_event_name,1,3)=="int", ]
  cy1 <- cy1[cy1$record_id %in% rd$record_id, ]
  
  cy1$OXadm  <- cy1$chemo_bl_doseadmin_o
  cy1$FUadm  <- cy1$chemo_bl_doseadmin_f_bolus
  cy1$FUcadm <- cy1$chemo_bl_doseadmin_f_cont
  cy1$CAPadm <- cy1$chemo_bl_doseadmin_c
  
  n3 <- (!is.na(cy1$chemo_bl_doseadmin_a1_plan)) + (!is.na(cy1$chemo_bl_doseadmin_a2_plan)) + (!is.na(cy1$chemo_bl_doseadmin_a3_plan))
  cy1$OXadm[is.na(cy1$OXadm) & n3==3]   <- cy1$chemo_bl_doseadmin_a1_plan[is.na(cy1$OXadm) & n3==3]
  cy1$FUcadm[is.na(cy1$FUcadm) & n3==3] <- cy1$chemo_bl_doseadmin_a2_plan[is.na(cy1$FUcadm) & n3==3]
  ## S05-01-0038: no FU bolus (irinotecan) -> a3 plan fills the FU slot
  cy1$FUadm[is.na(cy1$FUadm) & n3==3]  <- cy1$chemo_bl_doseadmin_a3_plan[is.na(cy1$FUadm) & n3==3]
  cy1$CAPadm[is.na(cy1$CAPadm) & n3==1] <- cy1$chemo_bl_doseadmin_a1_plan[is.na(cy1$CAPadm) & n3==1]
  cy1$FUadm[is.na(cy1$FUadm) & n3==2]  <- cy1$chemo_bl_doseadmin_a1_plan[is.na(cy1$FUadm) & n3==2]
  cy1$FUcadm[is.na(cy1$FUcadm) & n3==2]<- cy1$chemo_bl_doseadmin_a2_plan[is.na(cy1$FUcadm) & n3==2]
  
  cy1$Date.cy1   <- cy1$chemo_bl_date
  cy1$complete.. <- cy1$chemotherapy_baseline_complete
  cy1[, names(cy1) %in% c("record_id","OXadm","FUadm","FUcadm","CAPadm","Date.cy1","complete.."), drop=FALSE]
}
