#' Generate RDI Summary Table
#'
#' Subsets data by regimen (FOLFOX, CAPEX, Other) and calculates drug-specific RDI.
#'
#' @param MMM Master data frame containing cleaned chemotherapy and schedule data.
#' @export
#'
#'
FUN.RDI.table=function(MMM)
{
MMM$RDI_OX=MMM$RDI_FU=MMM$RDI_FUc=MMM$RDI_CAP=NA
MMM=MMM[MMM$Date.chemo>=MMM$rDate,]

MMMF=MMM[MMM$regimen=="FOLFOX",]
MMMC=MMM[MMM$regimen=="CAPEX",]
MMMO=MMM[MMM$regimen=="Other",]
MMMO=MMMO[MMMO$Current.Cycle.Number<=12,]


RDI_OXf=
  FUN.RDI(MMMF, "OXadm", "day.OX", "cyc.OX", "dose.OX", "RDI_OX")
RDI_FUf=
  FUN.RDI(MMMF, "FUadm", "day.FU", "cyc.FU", "dose.FU", "RDI_FU")
RDI_FUcf=
  FUN.RDI(MMMF, "FUcadm", "day.FUc", "cyc.FUc", "dose.FUc", "RDI_FUc")

RDI_OXc=
  FUN.RDI(MMMC, "OXadm", "day.OX", "cyc.OX", "dose.OX", "RDI_OX")
RDI_CAPc=
  FUN.RDI(MMMC, "CAPadm", "day.CAP", "cyc.CAP", "dose.CAP", "RDI_CAP")

RDI_OXo=
  FUN.RDI(MMMO, "OXadm", "day.OX", "cyc.OX", "dose.OX", "RDI_OX")
RDI_FUo=
  FUN.RDI(MMMO, "FUadm", "day.FU", "cyc.FU", "dose.FU", "RDI_FU")
RDI_FUco=
  FUN.RDI(MMMO, "FUcadm", "day.FUc", "cyc.FUc", "dose.FUc", "RDI_FUc")
RDI_CAPo=
  FUN.RDI(MMMO, "CAPadm", "day.CAP", "cyc.CAP", "dose.CAP", "RDI_CAP")


mgF1=merge(RDI_OXf, RDI_FUf, by="record_id")
mgF2=merge(mgF1, RDI_FUcf, by="record_id")
umgF2=mgF2[!duplicated(mgF2$record_id),]

mgC2=merge(RDI_OXc, RDI_CAPc, by="record_id")
umgC2=mgC2[!duplicated(mgC2$record_id),]


mgO1=merge(RDI_OXo, RDI_FUo, by="record_id")
mgO2=merge(mgO1, RDI_FUco, by="record_id")
mgO3=merge(mgO2, RDI_CAPo, by="record_id")
umgO3=mgO3[!duplicated(mgO3$record_id),]


umgF2$RDI=(umgF2$RDI_FU+umgF2$RDI_FUc+umgF2$RDI_OX)/3
umgC2$RDI=(umgC2$RDI_CAP+umgC2$RDI_OX)/2
umgO3$RDI=rowSums(umgO3[,c("RDI_OX", "RDI_FU", "RDI_FUc", "RDI_CAP")], na.rm=TRUE)/rowSums(!is.na(umgO3[,c("RDI_OX", "RDI_FU", "RDI_FUc", "RDI_CAP")]))

mmmF=merge(MMMF[,-which(names(MMMF)%in%c( "RDI_OX", "RDI_FU", "RDI_FUc"))], umgF2, by="record_id")
mmmC=merge(MMMC[,-which(names(MMMC)%in%c( "RDI_OX", "RDI_CAP"))], umgC2, by="record_id")
mmmO=merge(MMMO[,-which(names(MMMO)%in%c( "RDI_OX", "RDI_FU", "RDI_FUc", "RDI_CAP"))], umgO3, by="record_id")

mmmF=mmmF[order(mmmF$record_id, as.Date(mmmF$Date.chemo)),]
mmmC=mmmC[order(mmmC$record_id, as.Date(mmmC$Date.chemo)),]
mmmO=mmmO[order(mmmO$record_id, as.Date(mmmO$Date.chemo)),]

RMMM=rbind(mmmF, mmmC, mmmO)

#This is because S05-02-0056 has OX planned dose = 0, cycle = 0.
RMMM$RDI[RMMM$record_id=="S05-02-0056"]=RMMM$RDI_CAP[RMMM$record_id=="S05-02-0056"]

RDIs=RMMM[!duplicated(RMMM$record_id),]


RDIs$RDI[RDIs$record_id=="S05-01-0003"]=(RDIs$RDI_CAP[RDIs$record_id=="S05-01-0003"]+RDIs$RDI_OX[RDIs$record_id=="S05-01-0003"])/2

RDIs$RDI[RDIs$record_id=="A00-09-4321"]= 0.8467742


RDIs$RDI[RDIs$record_id=="S05-04-0002"]=0.7142857

RDIs$RDI[RDIs$record_id=="S05-02-0069"]=(0.7475879+0.952381)/2

RDIs$RDI[RDIs$regimen=="Other" & (!is.na(RDIs$cyc.CAP)) & (is.na(RDIs$cyc.OX)) & (is.na(RDIs$cyc.FU)) & (is.na(RDIs$cyc.FUc))]=RDIs$RDI_CAP[RDIs$regimen=="Other" & (!is.na(RDIs$cyc.CAP)) & (is.na(RDIs$cyc.OX)) & (is.na(RDIs$cyc.FU)) & (is.na(RDIs$cyc.FUc))]

RDIs$RDI[RDIs$record_id=="A00-09-3322"]= 0.5

#RDIs$RDI[RDIs$record_id=="S05-04-0002"] = 0.7142857
RDIs$RDI[RDIs$record_id=="S05-01-0021"] = 1




RDIs$cyc[RDIs$record_id=="S05-02-0056"]=8
RDIs$day[RDIs$record_id=="S05-02-0056"]=21


return(RDIs)
}

