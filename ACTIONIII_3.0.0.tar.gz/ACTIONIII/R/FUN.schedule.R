FUN.schedule <- function(api_url, api_token, rfields, sfields) {
  rd <- FUN.rd(api_url, api_token, rfields)
  sc <- as.data.frame(REDCapR::redcap_read(batch_size=300, redcap_uri=api_url,
                                           token=api_token, fields=sfields, verbose=FALSE)$data)
  sc <- sc[, names(sc) %in% sfields, drop=FALSE]
  sc <- sc[!is.na(sc$spc_chemo_regimen___1), ]
  sc <- sc[sc$record_id %in% rd$record_id, ]
  sc <- sc[!sc$record_id %in% c("S05-01-TEST","S05-02-TEST","S05-03-TEST","A00-00-TEST"), ]
  
  sc$cyc.OX  <- sc$spc_o_cyc;           sc$day.OX  <- sc$spc_o_cyclength;      sc$dose.OX  <- sc$spc_o_dose
  sc$cyc.FU  <- sc$spc_f_bolus_cyc;    sc$day.FU  <- sc$spc_f_bolus_cyclength; sc$dose.FU  <- sc$spc_f_bolus_dose
  sc$cyc.FUc <- sc$spc_f_cont_cyc;     sc$day.FUc <- sc$spc_f_cont_cyclength;   sc$dose.FUc <- sc$spc_f_cont_dose
  sc$cyc.CAP <- sc$spc_c_cyc;          sc$day.CAP <- sc$spc_c_cyclength;       sc$dose.CAP <- sc$spc_c_dose
  
  n3 <- (!is.na(sc$spc_cyc_a1)) + (!is.na(sc$spc_cyc_a2)) + (!is.na(sc$spc_cyc_a3))
  m3 <- n3 == 3          # three agents planned: a-fields take precedence
  sc$cyc.OX[m3]  <- sc$spc_cyc_a1[m3];  sc$day.OX[m3]  <- sc$spc_cyclength_a1[m3]; sc$dose.OX[m3]  <- sc$spc_dose_a1[m3]
  sc$cyc.FUc[m3] <- sc$spc_cyc_a2[m3];  sc$day.FUc[m3] <- sc$spc_cyclength_a2[m3]; sc$dose.FUc[m3] <- sc$spc_dose_a2[m3]
  sc$cyc.FU[m3]  <- sc$spc_cyc_a3[m3];  sc$day.FU[m3]  <- sc$spc_cyclength_a3[m3]; sc$dose.FU[m3]  <- sc$spc_dose_a3[m3]
  
  m2 <- n3 == 2          # two agents (e.g. S05-01-0038: no FU bolus, irinotecan)
  sc$cyc.FU[is.na(sc$cyc.FU) & m2]   <- sc$spc_cyc_a1[is.na(sc$cyc.FU) & m2]
  sc$day.FU[is.na(sc$day.FU) & m2]   <- sc$spc_cyclength_a1[is.na(sc$day.FU) & m2]
  sc$dose.FU[is.na(sc$dose.FU) & m2] <- sc$spc_dose_a1[is.na(sc$dose.FU) & m2]
  sc$cyc.FUc[is.na(sc$cyc.FUc) & m2] <- sc$spc_cyc_a2[is.na(sc$cyc.FUc) & m2]
  sc$day.FUc[is.na(sc$day.FUc) & m2] <- sc$spc_cyclength_a2[is.na(sc$day.FUc) & m2]
  sc$dose.FUc[is.na(sc$dose.FUc) & m2]<- sc$spc_dose_a2[is.na(sc$dose.FUc) & m2]
  
  m1 <- n3 == 1          # single agent -> capecitabine
  sc$cyc.CAP[is.na(sc$cyc.CAP) & m1]   <- sc$spc_cyc_a1[is.na(sc$cyc.CAP) & m1]
  sc$day.CAP[is.na(sc$day.CAP) & m1]   <- sc$spc_cyclength_a1[is.na(sc$day.CAP) & m1]
  sc$dose.CAP[is.na(sc$dose.CAP) & m1] <- sc$spc_dose_a1[is.na(sc$dose.CAP) & m1]
  
  sc$regimen <- NA
  sc$regimen[sc$spc_chemo_regimen___1==1] <- "FOLFOX"
  sc$regimen[sc$spc_chemo_regimen___2==1] <- "CAPEX"
  sc$regimen[sc$spc_chemo_regimen___3==1] <- "Other"
  sc$complete. <- sc$planned_chemotherapy_schedule_complete
  
  ## documented manual corrections
  sc$cyc.OX[sc$record_id=="S05-02-0056"] <- 8
  sc$cyc.OX[sc$record_id=="S05-02-0025"] <- 12
  
  sc[, names(sc) %in% c("record_id","cyc.OX","day.OX","dose.OX","cyc.FU","day.FU","dose.FU",
                        "cyc.FUc","day.FUc","dose.FUc","cyc.CAP","day.CAP","dose.CAP",
                        "regimen","complete."), drop=FALSE]
}
