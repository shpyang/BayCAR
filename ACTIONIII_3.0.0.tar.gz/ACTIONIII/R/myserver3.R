#' The postP.Bfun function
#'
#' @param input  The list of input variables.
#'
#' @param output  The list of output variables.
#'
#' @examples
#'
#' myserver(input, output)
#'
#' @export


myserver3 = function(input, output) {
  # Define a reactive value to hold the data
  data <- reactiveVal(NULL)

  outRDI_reactive <- reactive({
    isolate({
      res <- FUN.Extract_RDI()[[1]]
      res$group <- res$random_group
      res
    })
  })

  observeEvent(input$show, {

    arms = "3 arms"
    trial = "multi-site"
    planned.sample.size=180-17*2
    Continuous = NA
    covariates = c("site", "sex", "age", "random_chemo_duration", "random_fluoropyrimidine", "random_chemo_started", "random_age")
    covariates = c("site", "sex", "age", "random_chemo_duration", "random_fluoropyrimidine", "random_chemo_started", "random_age",                                          "random_date")

    scovariates = c("site", "sex", "random_age")

    IDID="record_id"
    groupletterID=LETTERS
    groupletterID=as.character(1:26)
    groupID="random_group"
    fields <- c(IDID, covariates, groupID)
    eventcol="redcap_event_name"
    events='ppt_arm_x'


    site=sex= random_age=random_chemo_duration=random_fluoropyrimidine=random_chemo_started=NA
    record_id=input$record_id

    ############ RDI

    outRDI <- outRDI_reactive()


    # --- ADD THE PLOT RENDERER HERE ---
    output$rdiBoxplot <- renderPlot({
      # 1. Calculate the number of subjects per group
      counts <- table(outRDI$group)

      # 2. Create the new labels: "GroupID (n=Count)"
      # This matches your example: 1 (n=10); 2 (n=11)
      level_names <- names(counts)
      new_labels <- paste0(level_names, " (n=", counts, ")")
      # Calculate means for each group
      means <- aggregate(RDI ~ group, data = outRDI, FUN = mean)$RDI
      # Round means for cleaner display (e.g., 1 decimal place)
      means_rounded <- round(means, 3)


      par(mfrow=c(1,2))
      boxplot(RDI ~ group,
              data = outRDI,
              main = "Relative Dose Intensity (RDI) by Group",
              xlab = "Group",
              ylab = "RDI (%)",
              names = new_labels, # This applies the new x-axis labels
              ylim=c(0, 1.1),
              cex.lab=1.5,
              cex.axis=1.3,
              col = c(8,2:7),
              pch = 16)

      # 4. Add the means below the boxes
      # bxp$stats[1, ] contains the lower whisker/minimum value for each box
      # We place the text slightly below that minimum value
      text(x = 1:length(means),
           y = 0.1, # Adjust the '- 2' to move text up or down
           labels =   means_rounded ,
           pos = 1, # Position text below the coordinate
           cex = 1.5 ) # Text color

    group.RDI=aggregate(outRDI$RDI, list(outRDI$group), FUN="mean")
    points(1:5, group.RDI$x, pch=16, col="orange", cex=2)
    points(1:5, group.RDI$x, pch=16, col="white", cex=1.5)

    ##
    outRDI3=outRDI[outRDI$group%in%c(1,2,3),]
    boxplot(RDI ~ group,
            data = outRDI3,
            main = "Relative Dose Intensity (RDI) by Group",
            xlab = "Group",
            ylab = "RDI (%)",
            names = new_labels[1:3], # This applies the new x-axis labels
            ylim=c(0, 1.1),
            cex.lab=1.5,
            cex.axis=1.3,
            col = c(8,2:7),
            pch = 16)

    # 4. Add the means below the boxes
    # bxp$stats[1, ] contains the lower whisker/minimum value for each box
    # We place the text slightly below that minimum value
    text(x = 1:3,
         y = 0.1, # Adjust the '- 2' to move text up or down
         labels =   means_rounded[1:3] ,
         pos = 1, # Position text below the coordinate
         cex = 1.5 ) # Text color

    group.RDI3=aggregate(outRDI3$RDI, list(outRDI3$group), FUN="mean")
    points(1:3, group.RDI3$x, pch=16, col="orange", cex=2)
    points(1:3, group.RDI3$x, pch=16, col="white", cex=1.5)
    }
    )



    #################
    # Read data from the project
    dataR <- redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(fields ), verbose=FALSE)
    Rdata=as.data.frame(dataR$data)

    #Rdata=read.csv("C:/Users/YangS/TEST.csv")

    Rdata$random_age=Rdata$age        #((Sys.Date()-as.Date(Rdata$dob))/365.25>=65)+1





     ##Rdata$random_group[Rdata$record_id=="A00-08-9499"]=NA






    #Rdata$Random_age
    covariates = c("site", "sex", "random_chemo_duration", "random_fluoropyrimidine", "random_chemo_started", "random_age")

    #covariates=covariates[covariates!="ppt_dob"]

    names(Rdata)=tolower(names(Rdata))
    data0=Rdata[substr(Rdata[,eventcol],1,3)=="ppt", -which(names(Rdata)==groupID)]
    data0=data0[!is.na(data0[, IDID]),]
    data0=data0[!duplicated(data0[, IDID]),]
    data1=Rdata[substr(Rdata[,eventcol],1,2)=="v2",]

    if (nrow(data1)>0)
    {data0=data0[,c(IDID, eventcol, covariates[covariates%in%scovariates])]
    data1=data1[,c(IDID, covariates[!covariates%in%scovariates],groupID)]
    data1=data1[data1[, IDID]%in%data0[, IDID],]
    } else
    {data1=data.frame(record_id=NA, random_chemo_duration=NA, random_fluoropyrimidine=NA, random_chemo_started=NA, random_group=NA)}

    if (all(data0[, IDID]%in%data1[, IDID])) {} else
    {ndata1=data.frame(record_id=data0[, IDID][!data0[, IDID]%in%data1[, IDID]],   random_chemo_duration=NA, random_fluoropyrimidine=NA, random_chemo_started=NA, random_group=NA)
    data1=rbind(data1, ndata1)
    data1=data1[!is.na(data1[,IDID]),]}

    datam=merge(data0, data1, by=IDID)
    datam[,IDID]=as.character(datam[,IDID])

    if (length(input$excludedid)==0) {eids="NO exclusion!"} else
    {excludedid <- input$excludedid
    excld2 <- tools::file_ext(excludedid$datapath)
    validate(need(excld2 == "xlsx", "Please upload a .xlsx file"))

    ex= as.data.frame(read_excel(excludedid$datapath, col_names  = TRUE))
    names(ex)=IDID
    eids=ex[,IDID]}

    datam0=datam=datam[!datam[,IDID]%in%eids,]
    duplicates=duplicated(datam0[,IDID])

    output$noID3=shiny::renderText("")
    if (nrow(datam0)==0) {
      output$noID3=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! All subjects have been excluded. Please confirm the data, close all the pop-up windows and run again!")) )) )
    }

    if (nrow(datam0)>0)
    {output$noID3=shiny::renderText("")
    if (any(duplicates)) {
      output$noID3=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! There are duplicated IDs (eg. ", paste(t(datam0[,IDID][duplicates])[1],sep=","), ") in the existing REDCap database. Please confirm the data, close all the pop-up windows and run again!")) )) )
    }

    newc=new=datam
    new=new[rowSums(is.na(new[,covariates]))==0,]
    new=datam[is.na(datam[,groupID]),]
    newc=datam[datam[,IDID]==input$record_id,]

    #  new=new[!is.na(new[,IDID])]
    if (any(names(new)==groupID)) {} else
    {new$random_group=NA}
    if (any(names(datam)==groupID)) {} else
    {if (nrow(datam)>0) {datam$random_group=NA}}
    new=new[,c(IDID, covariates, groupID)]
    new[,IDID]=as.character(new[,IDID])
    new[is.na(new[,groupID]), groupID]=""

    eventcol.char=nchar(events)
    siteid=new$site
    siteid[siteid=="PBRC (1)"]=1
    siteid[siteid=="Kaiser (2)"]=2
    siteid[siteid=="Dana Farber (3)"]=3
    new[,eventcol]=paste0(substr(events,1, (eventcol.char-1)), siteid)
    new2=new[new[,IDID]!=input$record_id,]
    new=new[new[,IDID]==input$record_id,]
    datam=datam[,c(IDID,eventcol, covariates, groupID)]
    datam[,IDID]=as.character(datam[,IDID])
    datam[,groupID][is.na(datam[,groupID])]=""

    output$missing.ran=shiny::renderUI("")

    if (nrow(new2)>1)
    {should.be.randomized= rep(NA, nrow(new2))
    for (i in 1:nrow(new2))
    {should.be.randomized[i]=(all(!is.na(new2[i,covariates]))&(all(new2[i, covariates]!=""))&(new2[i,groupID]==""))
    }
    if (any(should.be.randomized)) {
      srtext=new2[should.be.randomized,IDID][1]
      output$missing.ran=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! Some subjects (eg. ",  srtext, ") have covariate data, but not been randomized. Please confirm the data, close all the pop-up windows and run again!")) )) )}
    }

    datam=datam[datam[,groupID]!="",]

    wrandomized=rep(NA, nrow(datam))
    output$wrong.ran=shiny::renderUI("")

    for (i in 1:nrow(datam))
    {wrandomized[i]=any(is.na(datam[i,covariates]))&(datam[i,groupID]!=""&!is.na(datam[i,groupID]))
    }

    wdatam=datam[wrandomized,]

    if (nrow(wdatam)>0) {
      output$wrong.ran=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! Some subjects (eg. ", paste(wdatam[1,IDID], sep=","), "), have missing covariate data, but been randomized. Please confirm the data, close all the pop-up windows and run again!")) )) )}

    output$notnewID=shiny::renderText("")
    notnew=input$record_id%in%datam[datam[,groupID]!="",IDID]
    if (notnew) {
      output$notnewID=shiny::renderUI( HTML(as.character(div(style="color: red;",
                                                             paste0("Warning! This subject (", input$record_id,
                                                                    "), has already been randomized before. Please confirm the data, close all the pop-up windows and run again!")) ) ))}


    missingRDI=outRDI[is.na(outRDI$RDI),]
    if (nrow(missingRDI)>0) {
      output$missingRDI=shiny::renderUI( HTML(as.character(div(style="color: brown;", paste0("Warning! Some subjects (eg. ", paste(missingRDI[1,IDID], sep=","), "), have missing RDI data, but have completed the study. Please confirm the missing RDI data!")) )) )}



    ch.new=new
    if (nrow(new)<1)  {ch.new=newc}

    ch.new$site[ch.new$site==1]="PBRC (1)"
    ch.new$site[ch.new$site==2]="Kaiser (2)"
    ch.new$site[ch.new$site==3]="Dana Farber (3)"

    ch.new$sex [ch.new$sex==1]="Male (1)"
    ch.new$sex [ch.new$sex==2]="Female (2)"

    ch.new$random_age[ch.new$random_age==1]="<65 yrs (1)"
    ch.new$random_age[ch.new$random_age==2]=">=65 yrs (2)"

    ch.new$random_chemo_duration [ch.new$random_chemo_duration==1]="3 months (1)"
    ch.new$random_chemo_duration [ch.new$random_chemo_duration==2]="6 months (2)"

    ch.new$random_fluoropyrimidine  [ch.new$random_fluoropyrimidine ==1]="Intravenous (1)"
    ch.new$random_fluoropyrimidine  [ch.new$random_fluoropyrimidine ==2]="Oral (2)"

    ch.new$random_chemo_started   [ch.new$random_chemo_started  ==1]="Yes (1)"
    ch.new$random_chemo_started   [ch.new$random_chemo_started  ==0]="No (0)"

    names(ch.new)[names(ch.new)=="random_age"]="Age"
    names(ch.new)[names(ch.new)=="random_chemo_duration"]="Duration"
    names(ch.new)[names(ch.new)=="random_fluoropyrimidine"]="Fluoropyrimidine"
    names(ch.new)[names(ch.new)=="random_chemo_started"]="Chemo started?"


    { output$noID=shiny::renderText("                                           ")
      output$tablenew <- DT::renderDataTable(ch.new[, -which(names(ch.new)%in%c(eventcol, groupID))],
                                             options = list(dom = 't',bFilter=0,
                                                            autoWidth = TRUE,  columnDefs = list(list(orderable=FALSE,targets='_all', className = 'dt-center', visible=TRUE, width='100') ),
                                                            buttons = list(
                                                              list(extend = 'copy', title = "New data")),pageLength = 15, lengthChange = FALSE)
      )
    }

    output$noID1=shiny::renderText("")
    if ((nrow(new)<1)&(!input$record_id%in%datam0[,IDID])) {
      output$noID1=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! Subject ", record_id, " is not a new screened subject or has been excluded!"))) ) )
    }

    output$needcov=shiny::renderText("")
    if (any(is.na(new[, covariates]))) {
      output$needcov=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! Please input all covariate data!"))) ) )
    }


    output$needcov=shiny::renderText("")
    if (any(is.na(new[, covariates]))&nrow(new)>0) {
      output$needcov=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! Please input all covariate data! (Any duplicates? If so, STOP!)"))) ) )
    }


    output$noID2=shiny::renderText("")


nnewc<<-newc; ndatam0<<-datam0
    if (nrow(newc)>0)
    {if (any(!newc[,IDID]%in%datam0[, IDID])) { newIDID=newc[,IDID]
    output$noID2=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! This subject (e.g. ", newIDID[1], ") might have not been screened. Please confirm the data, close all the pop-up windows and run again!", sep=" "))) ) )
    }}

    output$noID4=shiny::renderText("")

    output$spce=shiny::renderText("")
  }}
  )

  ##############################################################################
  observeEvent(input$action, {

    arms = "3 arms"
    trial = "multi-site"
    planned.sample.size=180-17*2
    Continuous = NA
    covariates = c("site", "sex", "random_chemo_duration", "random_fluoropyrimidine", "random_chemo_started", "random_age")
    scovariates = c("site", "sex", "random_age")

    IDID="record_id"
    groupletterID=LETTERS
    groupletterID=as.character(1:26)
    groupID="random_group"
    fields <- c(IDID, covariates, groupID)
    eventcol="redcap_event_name"
    events='ppt_arm_x'

    site=sex=random_age=random_chemo_duration=random_fluoropyrimidine=random_chemo_started=NA
    record_id=input$record_id

    ############ RDI

    outRDI <- outRDI_reactive()
    req(outRDI)



    # Initial setup: Start with all 3 arms
    group.level=sort(as.numeric(groupletterID)[1:(as.numeric(substr(arms,1,1)))])

    # Initialize pRA for first iterations (uniform)
    pRA <- rep(1, length(group.level) - 1)
    pRA <- pRA / sum(pRA)

    # 3. Calculate Response Adaptive Probabilities (pRA)
    outRDI$group=outRDI$random_group
    tdata_available <- outRDI[!is.na(outRDI$RDI) & !is.na(outRDI$group), ]
    # Only calculate for active arms (excluding control '0')
    active_arms <- setdiff(group.level, "1")
    tdata_active <- tdata_available[tdata_available$group %in% active_arms, ]

    # Safety check: Need observations in active arms to update probabilities

    active_indices <- which(group.level %in% active_arms)

    premu=aggregate(tdata_available$RDI, list(tdata_available$group), FUN="mean")$x
    presd=100
    # Map results to current active arms
    pratio <- postP.Nfun(data.frame(trt=tdata_active$group, y=tdata_active$RDI),
                         premu[active_indices], presd)

    pRA <- pratio / sum(pratio)

    pRA_full <- c(max(pRA), pRA) # Mapping control probability to max of actives
    pRA_full <- pRA_full / sum(pRA_full)
    names(pRA_full)=group.level

    # --- ADD THE PLOT RENDERER HERE ---
    output$rdiBoxplot <- renderPlot({
      req(outRDI) # Ensure data exists
      # 1. Calculate the number of subjects per group
      counts <- table(outRDI$group)

      # 2. Create the new labels: "GroupID (n=Count)"
      # This matches your example: 1 (n=10); 2 (n=11)
      level_names <- names(counts)
      new_labels <- paste0(level_names, " (n=", counts, ")")
      # Calculate means for each group
      means <- aggregate(RDI ~ group, data = outRDI, FUN = mean)$RDI
      # Round means for cleaner display (e.g., 1 decimal place)
      means_rounded <- round(means, 3)

      par(mfrow=c(1,2))
      boxplot(RDI ~ group,
              data = outRDI,
              main = "Relative Dose Intensity (RDI) by Group",
              xlab = "Group",
              ylab = "RDI (%)",
              names = new_labels, # This applies the new x-axis labels
              ylim=c(0, 1.1),
              cex.lab=1.5,
              cex.axis=1.3,
              col = c(8,2:7),
              pch = 16)

      # 4. Add the means below the boxes
      # bxp$stats[1, ] contains the lower whisker/minimum value for each box
      # We place the text slightly below that minimum value
      text(x = 1:length(means),
           y = 0.1, # Adjust the '- 2' to move text up or down
           labels =   means_rounded ,
           pos = 1, # Position text below the coordinate
           cex = 1.5 ) # Text color

      group.RDI=aggregate(outRDI$RDI, list(outRDI$group), FUN="mean")
      points(1:5, group.RDI$x, pch=16, col="orange", cex=2)
      points(1:5, group.RDI$x, pch=16, col="white", cex=1.5)


      ##
      outRDI3=outRDI[outRDI$group%in%c(1,2,3),]
      boxplot(RDI ~ group,
              data = outRDI3,
              main = "Relative Dose Intensity (RDI) by Group",
              xlab = "Group",
              ylab = "RDI (%)",
              names = new_labels[1:3], # This applies the new x-axis labels
              ylim=c(0, 1.1),
              cex.lab=1.5,
              cex.axis=1.3,
              col = c(8,2:7),
              pch = 16)

      # 4. Add the means below the boxes
      # bxp$stats[1, ] contains the lower whisker/minimum value for each box
      # We place the text slightly below that minimum value
      text(x = 1:3,
           y = 0.1, # Adjust the '- 2' to move text up or down
           labels =   means_rounded[1:3] ,
           pos = 1, # Position text below the coordinate
           cex = 1.5 ) # Text color

      group.RDI3=aggregate(outRDI3$RDI, list(outRDI3$group), FUN="mean")
      points(1:3, group.RDI3$x, pch=16, col="orange", cex=2)
      points(1:3, group.RDI3$x, pch=16, col="white", cex=1.5)

    }
    )

    #################
        # Read data from the project
    dataR <- redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(fields, "age", "random_date"), verbose=FALSE)
    Rdata=as.data.frame(dataR$data)












     #Rdata$random_group[Rdata$record_id=="A00-08-9499"]=NA













    #Rdata=read.csv("C:/Users/YangS/TEST.csv")

    Rdata=Rdata[Rdata$random_group%in%names(pRA_full) |(is.na(Rdata$random_group)) | (Rdata$record_id==record_id),]
    Rdata$random_age= Rdata$age                             #((Sys.Date()-as.Date(Rdata$dob))/365.25>=65)+1

    names(Rdata)=tolower(names(Rdata))
    data0=Rdata[substr(Rdata[,eventcol],1,3)=="ppt", -which(names(Rdata)==groupID)]
    data0=data0[!is.na(data0[, IDID]),]
    data0=data0[!duplicated(data0[, IDID]),]
    data1=Rdata[substr(Rdata[,eventcol],1,2)=="v2",]

    if (nrow(data1)>0)
    {data0=data0[,c(IDID, eventcol, c("age", covariates[covariates%in%scovariates]))]
    data1=data1[,c(IDID, covariates[!covariates%in%scovariates],groupID,"random_date")]
    data1=data1[data1[, IDID]%in%data0[, IDID],]
    } else
    {data1=data.frame(record_id=NA, random_chemo_duration=NA, random_fluoropyrimidine=NA, random_chemo_started=NA, random_group=NA, random_date=NA)}

    if (all(data0[, IDID]%in%data1[, IDID])) {} else
    {ndata1=data.frame(record_id=data0[, IDID][!data0[, IDID]%in%data1[, IDID]],   random_chemo_duration=NA, random_fluoropyrimidine=NA, random_chemo_started=NA, random_group=NA, random_date=NA)
    data1=rbind(data1, ndata1)
    data1=data1[!is.na(data1[,IDID]),]}

    datam=merge(data0, data1, by=IDID)
    datam[,IDID]=as.character(datam[,IDID])

    #datam$random_age2=(as.numeric(as.Date(datam$random_date)-as.Date(datam$dob))/365.25>=65)+1
    #datam$random_age[datam$random_age!=datam$random_age2&(!is.na(datam$random_age))&(!is.na(datam$random_age2))]=datam$random_age2[datam$random_age!=datam$random_age2&(!is.na(datam$random_age))&(!is.na(datam$random_age2))]

    datam$random_age2=(datam$random_age>=65)+1
    datam$random_age=datam$random_age2


    datam=datam[, -which(names(datam)%in%c("age","random_age2", "random_date"))]

    if (length(input$excludedid)==0) {eids="NO exclusion!"} else
    {excludedid <- input$excludedid
    excld2 <- tools::file_ext(excludedid$datapath)
    validate(need(excld2 == "xlsx", "Please upload a .xlsx file"))

    ex= as.data.frame(read_excel(excludedid$datapath, col_names  = TRUE))
    names(ex)=IDID
    eids=ex[,IDID]}

    datam0=datam=datam[!datam[,IDID]%in%eids,]
    duplicates=duplicated(datam0[,IDID])

    new=datam[is.na(datam[,groupID]),]

    if (any(names(new)==groupID)) {} else
    {new$random_group=NA}
    if (any(names(datam)==groupID)) {} else
    {if (nrow(datam)>0) {datam$random_group=NA}}
    new=new[,c(IDID, covariates, groupID)]
    new[,IDID]=as.character(new[, IDID])

    eventcol.char=nchar(events)
    siteid=new$site
    siteid[siteid=="PBRC (1)"]=1
    siteid[siteid=="Kaiser (2)"]=2
    siteid[siteid=="Dana Farber (3)"]=3

    new[,eventcol]=paste0(substr(events, 1, (eventcol.char-1)), siteid)
    #new2=new[new[,IDID]!=input$record_id,]
    new=new[new[,IDID]==input$record_id,]

print("This is the new participant:")
#print(new)

    output$noID5=shiny::renderText("")
    if (input$random_eligible!="Yes!") {
      output$noID5=shiny::renderUI( HTML(as.character(div(style="color: red;", "Warning! This is NOT an eligible subject. Please confirm the data, close all the pop-up windows and run again!")) ) )
    } else  if (record_id%in%datam[!is.na(datam[,groupID]),IDID]) {
      output$noID5=shiny::renderUI( HTML(as.character(div(style="color: red;", "Warning! This subject has already been randomized. Please confirm the data, close all the pop-up windows and run again!")) ) )
    } else  if (nrow(new)==0) {
      output$noID5=shiny::renderUI( HTML(as.character(div(style="color: red;", "Warning! This is not a new screened subject or has been excluded. Please confirm the data, close all the pop-up windows and run again!")) ) )
    } else  if (!new[,IDID]%in%data0[,IDID]) {
      output$noID5=shiny::renderUI( HTML(as.character(div(style="color: red;", "Warning! This subject has not been screened. Please confirm the data, close all the pop-up windows and run again!")) ) )
    } else  if (any(is.na(new[,covariates]))) {
      output$noID5=shiny::renderUI( HTML(as.character(div(style="color: red;", "Warning! This subject has missing covariates data. Please confirm the data, close all the pop-up windows and run again!")) ) )
    } else
    {



    datam=datam[,c(IDID,eventcol, covariates, groupID)]
    datam[,IDID]=as.character(datam[,IDID])
    datam[,groupID][is.na(datam[,groupID])]=""
    datam=datam[datam[,groupID]!="",]

    wr=mr=rep(FALSE, nrow(datam))

    if (nrow(datam)>0)
    {for (i in 1:nrow(datam))
    {mr[i]=all(!is.na(datam[i,covariates]))&(datam[i,groupID]=="")
     wr[i]=any(is.na(datam[i,covariates]))&(datam[i,groupID]!="")
    }}

    {
    for (i in 1:length(covariates))
    {if  (is.factor(new[,covariates[i]])) {new[,covariates[i]]=as.character(new[,covariates[i]])}
      if  (is.factor(datam[,covariates[i]])) {datam[,covariates[i]]=as.character(datam[,covariates[i]])}
      new[is.na(new[,covariates[i]]),covariates[i]]=""
      new=new[new[,covariates[i]]!="",]
      datam[is.na(datam[,covariates[i]]),covariates[i]]=""
      datam=datam[datam[,covariates[i]]!="",]
    }

    if (nrow(datam)==0) {data=new} else
    {data=rbind(datam, new)}

    dataevent=data[, c(IDID, eventcol)]
    data=data[!duplicated(data[, IDID]),]

    covnames=names(data)
    categorical=covnames[!covnames%in%c(IDID, eventcol, groupID)]
    categorical=categorical[categorical%in%covariates]
    Continuous= Continuous
    Continuous=Continuous[Continuous%in%names(data)]
    categorical=categorical[!categorical%in%Continuous]

    if (trial=="single-site")
    {categorical=categorical[!categorical%in%c("site")]}

    data$random_group[is.na(data$random_group)]=""
    planned.sample.size= planned.sample.size

    if (trial=="multi-site")
    {  categoricalx=c(categorical[!categorical%in%c("site")])
    for (i in 1:length(categoricalx))
    {interi=as.factor(as.character(paste(data$site, data[,categoricalx[i]], sep="-")))

    if (i==1) {inx=data.frame(interi)} else {inx=data.frame(inx, interi)}
    }
    inx=as.data.frame(inx)
    names(inx)=paste0("site-",categoricalx)
    data=cbind(data,inx)

    if (length(Continuous)>0)
    {
      nsite=rep(NA, nrow(data))
      nsite[data$site=="PBRC (1)"]=1
      nsite[data$site=="Kaiser (2)"]=2
      nsite[data$site=="Dana Farber (3)"]=3

      for (j in 1:length(Continuous))
      {sContinuous=nsite*data[,Continuous[j]]
      if (j==1) {dContinous=sContinuous} else
      {dContinous=cbind(dContinous, sContinuous)}
      }
      dContinous=as.data.frame(dContinous)
      names(dContinous)=paste0("site-", Continuous)
      data=cbind(data, dContinous)
      Continuous=c(Continuous, names(dContinous))
    }
    categorical=names(data)[-which(names(data)%in%c(IDID, eventcol, groupID, Continuous))]
    }

        #eids=c(strsplit(input$excludedid, ",")[[1]])
    if (length(input$excludedid)==0) {eids="NO exclusion!"} else
    {excludedid <- input$excludedid
    excld2 <- tools::file_ext(excludedid$datapath)
    validate(need(excld2 == "xlsx", "Please upload a .xlsx file"))

    ex= as.data.frame(read_excel(excludedid$datapath, col_names = TRUE))
    names(ex)=IDID

    eids=ex[,IDID]}
    if (any(eids%in%data[, IDID]))
    {excluded.data=data[data[, IDID]%in%eids,]
    data=data[!data[, IDID]%in%eids,]}

    datab=data


    group.level=as.factor(group.level)
    if (length(Continuous)<1)
    {
      data$random_group=
        FUN.BCAR(data,
               group.var = groupID,
               categorical.covariates =  categorical, group.level=group.level,
               planned.sample.size = planned.sample.size,
               pRA=pRA_full, tuning = .2, tuning2 = 1)

    } else
    {data$random_group=
      FUN.BCAR(data,
               group.var = groupID,
               categorical.covariates =  categorical, continuous.covariates = c(Continuous), group.level=group.level,
               planned.sample.size = planned.sample.size,
               pRA=pRA_full, tuning = .2, tuning2 = 1)
    }


    outdata0=outdata1=outdata=data
    outdata0=outdata[,c(IDID, eventcol, covariates[covariates%in%c("site", "sex")])]
    outdata1=outdata[,c(IDID, eventcol, covariates[!covariates%in%c("site", "sex")], groupID)]
    outdata1=outdata[,c(IDID, eventcol,                                              groupID)]
    outdata0=outdata[,c(IDID, eventcol)]
    #outdata1=outdata[,c(IDID, eventcol, covariates, groupID)]
    outdata1[, eventcol]=paste0("v2", substr(outdata1[, eventcol], 4, 50))

    for (i in 1:length(covariates))
    {wh.name=which(tolower(names(outdata0))==tolower(covariates[i]))
    names(outdata0)[wh.name]=covariates[i]
    }

    outdata1out=outdata1[outdata1$record_id==record_id,]
    #write.csv(outdata1out, paste("C:/Users/YangS/rand.out.", Sys.Date(), ".csv"), row.names=FALSE)

    newlyRandomized=NULL
    newlyRandomized=data[data[, IDID]%in%datab[, IDID][(is.na(datab$random_group))|(datab$random_group=="")],]
    newlyRandomizedout=newlyRandomized[,c(IDID, eventcol,                                              groupID)]
    newlyRandomizedout[, eventcol]=paste0("v2", substr(newlyRandomizedout[, eventcol], 4, 50))

    #write.csv(newlyRandomizedout, paste("C:/Users/YangS/rand.out.1.", Sys.Date(), ".csv"), row.names=FALSE)

print(newlyRandomizedout)
     redcap_write(newlyRandomizedout,redcap_uri=api_url, token=api_token)

    for (i in 1:( length(categorical)))
    { data[,categorical[i]]=as.factor(data[,categorical[i]])}
    out=vector("list", 1+length(categorical))
    data$`Assigned group`=rep("Number of subjects", nrow(data))
    for (i in 1:(1+length(categorical)))
    { dd=table(as.factor(data[,c("Assigned group", categorical)[i]]), factor(data$random_group, group.level))
    ddd= as.data.frame.matrix(dd)
    ddd$var=row.names(ddd)
    names(ddd)[names(ddd)=="var"]=c("Assigned group", categorical)[i]
    out[[i]]=ddd
    }

    if (input$display=="No")
    {out=vector("list", 1+length(categorical))}

    df_names=paste0("table", 1:(1+length(categorical)))

    for (i in 1:(1+length(categorical)))
    { local({i<-i;
    output[[df_names[i]]] = DT::renderDataTable(out[[i]], rownames=FALSE,
                                                options = list(dom = 't',bFilter=0, autoWidth = TRUE,
                                                               columnDefs = list( list(targets = as.numeric(substr(input$arms,1,1)), className = "dt-center", createdCell = JS("function(td, cellData, rowData, row, col) {td.style.color = 'blue';}")),
                                                                                  #list(targets = 0                                   , className = "dt-center", createdCell = JS("function(td, cellData, rowData, row, col) {td.style.color = 'white';}")),
                                                                                  list(orderable=FALSE, targets='_all', className = 'dt-center', visible=TRUE, width='100') ),
                                                               buttons = list(list(extend = 'copy', title = "My custom title 1")), pageLength = 15, lengthChange = FALSE,
                                                               initComplete = JS(
                                                                 "function(settings, json) {",
                                                                 "$(this.api().table().header()).css({'background-color': 'blue', 'color': 'white'});",
                                                                 "}"))
    )})}

    if (nrow(newlyRandomized)<1)
    {newlyRandomized=NULL
    NOnewlyRandomized="No new group assignment was made. Please make sure this NEW subject has not been randomized earlier."
    output$WNOnewlyRandomized=shiny::renderUI( HTML(as.character(div(style="color: red;", NOnewlyRandomized))))} else
    {
      output$WNOnewlyRandomized=shiny::renderUI( HTML(as.character(div(style="color: red;", ""))))

      output$table99=NULL
      output$table99 <- DT::renderDataTable(newlyRandomized[,c(IDID, groupID)], rownames=FALSE,
                                            options = list(dom = 't',bFilter=0,addClass = 'green-table',  autoWidth = TRUE,
                                                           columnDefs = list(# list(targets = 0                                   , className = "dt-center", createdCell = JS("function(td, cellData, rowData, row, col) {td.style.color = 'white';}")),
                                                                              list(orderable=FALSE, targets='_all', className = 'dt-center', visible=TRUE, width='90')
                                                           ),
                                                           initComplete = JS( "function(settings, json) {",  "$(this.api().table().header()).css({'background-color': 'green', 'color': 'white'});", "}"),
                                                           pageLength = 15, lengthChange = FALSE)
                                            )



      outframenew=data.frame(newlyRandomized[,c(IDID, groupID)], "Response biasing probabilities: ", t(pRA_full), "Arm means: ", t(premu))
       names(outframenew)=c("ID", "group", "---", "arm 1", "arm 2", "arm 3", "---", "arm 1", "arm 2", "arm 3", "arm 4", "arm 5")

      output$downloadData <- downloadHandler(
        filename = function() { paste0("Randomization data for the new subject(s).",Sys.Date(), ".csv") },
        content = function(file) {
          write.csv(outframenew, file, row.names = FALSE)
        }
      )
    }

    output$downloadDataC <- downloadHandler(
      filename = function() { paste0("Randomization data for all subjects.",Sys.Date(), ".csv") },
      content = function(file) {
        write.csv(data[,c(IDID, covariates, groupID)], file, row.names = FALSE)
      }
    )
    if (eids[1]!="NO exclusion!")
    {eex=ex; names(eex)="Excluded IDs"
    output$table98 <- DT::renderDataTable(eex,
                                          options = list(dom = 't',bFilter=0,
                                                         autoWidth = TRUE,  columnDefs = list(list(orderable=FALSE,targets='_all', className = 'dt-center', visible=TRUE, width='50') ),
                                                         buttons = list(
                                                           list(extend = 'copy', title = "My custom title 1")),pageLength = 15, lengthChange = FALSE)
    )}






    }
    }
   }
  )


}



