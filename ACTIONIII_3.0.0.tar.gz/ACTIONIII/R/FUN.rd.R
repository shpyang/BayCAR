#' Randomization data
#'
#' Connects to the REDCap API to retrieve longitudinal chemotherapy dose
#' administration data. It cleans record IDs and formats chemotherapy dates.
#'
#' @param api_url Character; the REDCap API endpoint URL.
#' @param api_token Character; the project-specific API token.
#' @param rfields Character vector of randomization/demographic fields to fetch.
#'
#' @export
#'
FUN.rd <- function(api_url, api_token, rfields) {

  # randonmization
  rfields=c("record_id", "random_age", "random_chemo_duration", "random_fluoropyrimidine",
            "random_chemo_started", "random_date", "random_group", "sex", "age", "dob")

  rraann= redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(rfields), verbose=FALSE)
  rraa=as.data.frame(rraann$data)


  rraa=rraa[!rraa$record_id%in%c("S05-01-TEST", "S05-02-TEST", "S05-03-TEST", "A00-00-TEST", "S05-01-TEST"),]
  rraa$rDate=as.Date(rraa$random_date)
  rraa1=rraa[substr(toupper(rraa$redcap_event_name ),1,3)=="PPT", c(1,5,6,7)]
  #rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,9:14)]
  rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,8:13)]
  rraa2=rraa2[!is.na(rraa2$random_group),]

  rd=merge(rraa1, rraa2, by="record_id", all.y=TRUE)
  rd$dur=rd$random_chemo_duration
  #rd$rage=floor((rd$random_date-rd$dob)/365.25)
  #rd$age=rd$rage
  rd=rd[, -which(names(rd)%in%c("rage", "random_date"))]
  #rd$agee= round(as.Date(rd$rDate)-as.Date(rd$dob))/365.25
  rd=rd[!is.na(rd$rDate),]


  table(rd$random_group)
  # rd$agee= round(as.Date(rd$rDate)-as.Date(rd$dob))/365.25
  #plot(rd$age, rd$agee, pch=16); abline(0,1, col=2)

  rd=rd[!is.na(rd$rDate),]

}
