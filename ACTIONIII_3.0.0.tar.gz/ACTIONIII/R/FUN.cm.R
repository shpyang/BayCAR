#' Fetch REDCap Chemotherapy Administration Records
#'
#' Connects to the REDCap API to retrieve longitudinal chemotherapy dose
#' administration data. It cleans record IDs and formats chemotherapy dates.
#'
#' @param api_url Character; the REDCap API endpoint URL.
#' @param api_token Character; the project-specific API token.
#' @param rfields Character vector of randomization/demographic fields to fetch.
#' @param mfields Character vector of chemotherapy-specific administration fields.
#'
#' @return A data frame containing cleaned chemotherapy administration records
#'   with standardized column names (OXadm, FUadm, etc.).
#' @export
#'
#'
#'
FUN.cm <- function(api_url, api_token, rfields, mfields) {
  rd <- FUN.rd(api_url, api_token, rfields)
  cm <- as.data.frame(REDCapR::redcap_read(batch_size=300, redcap_uri=api_url,
                                           token=api_token, fields=mfields, verbose=FALSE)$data)
  cm <- cm[substr(cm$redcap_event_name,1,3)=="int", ]
  cm <- cm[cm$record_id %in% rd$record_id, ]
  cm <- cm[!is.na(cm$chemo_date) & as.character(cm$chemo_date) != "", ]

  ## documented manual corrections
  cm$chemo_date[cm$record_id=="S05-02-0025" & !is.na(cm$chemo_cyc) & cm$chemo_cyc==5] <- "2024-12-03"
  cm$chemo_date[cm$record_id=="S05-01-0016" & !is.na(cm$chemo_cyc) & cm$chemo_cyc==3] <- "2024-05-28"
  cm$chemo_doseadmin_a1_plan[cm$record_id=="A00-09-3322"] <- cm$chemo_doseadmin_a1[cm$record_id=="A00-09-3322"]
  cm$chemo_cyc[cm$record_id=="S05-02-0035" & !is.na(cm$chemo_date) &
                 as.character(cm$chemo_date)=="2025-03-25"] <- 4

  cm$OXadm  <- cm$chemo_doseadmin_o
  cm$FUadm  <- cm$chemo_doseadmin_f_bolus
  cm$FUcadm <- cm$chemo_doseadmin_f_cont
  cm$CAPadm <- cm$chemo_doseadmin_c

  n3 <- (!is.na(cm$chemo_doseadmin_a1_plan)) + (!is.na(cm$chemo_doseadmin_a2_plan)) + (!is.na(cm$chemo_doseadmin_a3_plan))
  cm$OXadm[is.na(cm$OXadm) & n3==3]   <- cm$chemo_doseadmin_a1_plan[is.na(cm$OXadm) & n3==3]
  cm$FUadm[is.na(cm$FUadm) & n3==3]  <- cm$chemo_doseadmin_a3_plan[is.na(cm$FUadm) & n3==3]
  cm$FUcadm[is.na(cm$FUcadm) & n3==3]<- cm$chemo_doseadmin_a2_plan[is.na(cm$FUcadm) & n3==3]
  cm$FUadm[is.na(cm$FUadm) & n3==2]  <- cm$chemo_doseadmin_a1_plan[is.na(cm$FUadm) & n3==2]
  cm$FUcadm[is.na(cm$FUcadm) & n3==2]<- cm$chemo_doseadmin_a2_plan[is.na(cm$FUcadm) & n3==2]
  cm$CAPadm[is.na(cm$CAPadm) & n3==1]<- cm$chemo_doseadmin_a1_plan[is.na(cm$CAPadm) & n3==1]  # FIXED: LHS/RHS both CAPadm

  cm$Date.cm     <- cm$chemo_date
  cm$complete... <- cm$chemotherapy_complete
  cm$Current.Cycle.Number <- cm$chemo_cyc

  cm <- cm[, names(cm) %in% c("record_id","OXadm","FUadm","FUcadm","CAPadm",
                              "Date.cm","complete...","Current.Cycle.Number"), drop=FALSE]
  cm[rowSums(is.na(cm)) < ncol(cm) - 1, ]
}
