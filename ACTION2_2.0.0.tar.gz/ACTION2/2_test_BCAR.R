
library(ACTION2)

data=read.csv("H:/WFH/ACTION2/ACTION2/data.csv")

data=data[order(data$random_group),]

cvar0=c("sex", "random_chemo_duration", "random_fluoropyrimidine", "random_chemo_started", "random_age")


cvar=c("sex", "random_chemo_duration", "random_fluoropyrimidine", "random_chemo_started", "random_age", "site.sex", "site.random_chemo_duration", "site.random_fluoropyrimidine", "site.random_chemo_started", "site.random_age")

group=FUN.BCAR(data, group.var="group", categorical.covariates=cvar,
              group.level=c(1,2,3))

 
i=which(is.na(data$group))
tun=.2


for (j in 1:length(cvar0)) {
  NN.out = FNN.out(data, i, cvar0[j],
                   1, 1, group.level = 1:3)
  NN.out[[1]] = NN.out[[1]]/sum(NN.out[[1]])
  print(NN.out[[1]])
  if (j == 1) { kk=NN.out[[1]] } else { kk = kk * NN.out[[1]] }
}

nkk=(kk/sum(kk))^tun
nkk/sum(nkk)


for (j in 1:length(cvar)) {
  NN.out = FNN.out(data, i, cvar[j],
                   1, 1, group.level = 1:3)
  NN.out[[1]] = NN.out[[1]]/sum(NN.out[[1]])
  print(NN.out[[1]])
  if (j == 1) { kk=NN.out[[1]] } else { kk = kk * NN.out[[1]] }
}

nkk=(kk/sum(kk))^tun
 nkk/sum(nkk)
 
 
 
 
 
 
 
 
 
 
 
eps = 1e-6

for (j in 1:length(cvar)) {
  NN.out = FNN.out(data, i, cvar[j],
                   1, 1, group.level = 1:3)
  NN.out[[1]] = NN.out[[1]]/sum(NN.out[[1]])
  print(NN.out[[1]])
  if (j == 1) { PPP=log(pmax(NN.out[[1]], eps)) } else { PPP = PPP + log(pmax(NN.out[[1]], eps))  }
}

proba = exp(PPP) / sum(exp(PPP))

proba


