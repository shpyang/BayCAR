

arms = "3 arms"
trial = "multi-site"
planned.sample.size=180-17*2
Continuous = NA
covariates = c("site", "sex", "random_chemo_duration", "random_fluoropyrimidine", "random_chemo_started", "random_age")
scovariates = c("site", "sex", "random_age")

IDID="record_id"
groupletterID=LETTERS
groupletterID=as.character(1:26)
groupID="random_group"
fields <- c(IDID, covariates, groupID)
eventcol="redcap_event_name"
events='ppt_arm_x'

site=sex=random_age=random_chemo_duration=random_fluoropyrimidine=random_chemo_started=NA
record_id="A00-08-9499"

res <- FUN.Extract_RDI()[[1]]
outRDI=res

# Initial setup: Start with all 3 arms
group.level=sort(as.numeric(groupletterID)[1:(as.numeric(substr(arms,1,1)))])

# Initialize pRA for first iterations (uniform)
pRA <- rep(1, length(group.level) - 1)
pRA <- pRA / sum(pRA)

# 3. Calculate Response Adaptive Probabilities (pRA)
outRDI$group=outRDI$random_group
tdata_available <- outRDI[!is.na(outRDI$RDI) & !is.na(outRDI$group), ]
# Only calculate for active arms (excluding control '0')
active_arms <- setdiff(group.level, "1")
tdata_active <- tdata_available[tdata_available$group %in% active_arms, ]

# Safety check: Need observations in active arms to update probabilities

active_indices <- which(group.level %in% active_arms)

premu=aggregate(tdata_available$RDI, list(tdata_available$group), FUN="mean")$x
presd=100
# Map results to current active arms
pratio <- postP.Nfun(data.frame(trt=tdata_active$group, y=tdata_active$RDI),
                     premu[active_indices], presd)

pRA <- pratio / sum(pratio)

pRA_full <- c(max(pRA), pRA) # Mapping control probability to max of actives
pRA_full <- pRA_full / sum(pRA_full)
names(pRA_full)=group.level

  # 1. Calculate the number of subjects per group
  counts <- table(outRDI$group)

  # 2. Create the new labels: "GroupID (n=Count)"
  # This matches your example: 1 (n=10); 2 (n=11)
  level_names <- names(counts)
  new_labels <- paste0(level_names, " (n=", counts, ")")
  # Calculate means for each group
  means <- aggregate(RDI ~ group, data = outRDI, FUN = mean)$RDI
  # Round means for cleaner display (e.g., 1 decimal place)
  means_rounded <- round(means, 3)


  boxplot(RDI ~ group,
          data = outRDI,
          main = "Relative Dose Intensity (RDI) by Group",
          xlab = "Group",
          ylab = "RDI (%)",
          names = new_labels, # This applies the new x-axis labels
          ylim=c(0, 1.1),
          cex.lab=1.5,
          cex.axis=1.3,
          col = c(8,2:7),
          pch = 16)

  # 4. Add the means below the boxes
  # bxp$stats[1, ] contains the lower whisker/minimum value for each box
  # We place the text slightly below that minimum value
  text(x = 1:length(means),
       y = 0.1, # Adjust the '- 2' to move text up or down
       labels =   means_rounded ,
       pos = 1, # Position text below the coordinate
       cex = 1.5 )


  dataR <- redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(fields, "age", "random_date"), verbose=FALSE)
  Rdata=as.data.frame(dataR$data)



  dataR <- redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(fields, "age", "random_date"), verbose=FALSE)
  Rdata=as.data.frame(dataR$data)

  Rdata$random_group[Rdata$record_id=="A00-08-9499"]=NA



  Rdata=Rdata[Rdata$random_group%in%names(pRA_full) |(is.na(Rdata$random_group)) | (Rdata$record_id==record_id),]
  Rdata$random_age= Rdata$age

  names(Rdata)=tolower(names(Rdata))
  data0=Rdata[substr(Rdata[,eventcol],1,3)=="ppt", -which(names(Rdata)==groupID)]
  data0=data0[!is.na(data0[, IDID]),]
  data0=data0[!duplicated(data0[, IDID]),]
  data1=Rdata[substr(Rdata[,eventcol],1,2)=="v2",]

  if (nrow(data1)>0)
  {data0=data0[,c(IDID, eventcol, c("age", covariates[covariates%in%scovariates]))]
  data1=data1[,c(IDID, covariates[!covariates%in%scovariates],groupID,"random_date")]
  data1=data1[data1[, IDID]%in%data0[, IDID],]
  } else
  {data1=data.frame(record_id=NA, random_chemo_duration=NA, random_fluoropyrimidine=NA, random_chemo_started=NA, random_group=NA, random_date=NA)}

  if (all(data0[, IDID]%in%data1[, IDID])) {} else
  {ndata1=data.frame(record_id=data0[, IDID][!data0[, IDID]%in%data1[, IDID]],   random_chemo_duration=NA, random_fluoropyrimidine=NA, random_chemo_started=NA, random_group=NA, random_date=NA)
  data1=rbind(data1, ndata1)
  data1=data1[!is.na(data1[,IDID]),]}

  datam=merge(data0, data1, by=IDID)
  datam[,IDID]=as.character(datam[,IDID])

  datam$random_age2=(datam$random_age>=65)+1
  datam$random_age=datam$random_age2


  datam=datam[, -which(names(datam)%in%c("age","random_age2", "random_date"))]


  datam0=datam=datam
  duplicates=duplicated(datam0[,IDID])

  new=datam[is.na(datam[,groupID]),]

  if (any(names(new)==groupID)) {} else
  {new$random_group=NA}
  if (any(names(datam)==groupID)) {} else
  {if (nrow(datam)>0) {datam$random_group=NA}}
  new=new[,c(IDID, covariates, groupID)]
  new[,IDID]=as.character(new[, IDID])

  eventcol.char=nchar(events)
  siteid=new$site
  siteid[siteid=="PBRC (1)"]=1
  siteid[siteid=="Kaiser (2)"]=2
  siteid[siteid=="Dana Farber (3)"]=3

  new[,eventcol]=paste0(substr(events, 1, (eventcol.char-1)), siteid)
  #new2=new[new[,IDID]!=input$record_id,]
  new=new[new[,IDID]=="A00-08-9499",]


  datam=datam[,c(IDID,eventcol, covariates, groupID)]
  datam[,IDID]=as.character(datam[,IDID])
  datam[,groupID][is.na(datam[,groupID])]=""
  datam=datam[datam[,groupID]!="",]

  wr=mr=rep(FALSE, nrow(datam))

  if (nrow(datam)>0)
  {for (i in 1:nrow(datam))
  {mr[i]=all(!is.na(datam[i,covariates]))&(datam[i,groupID]=="")
  wr[i]=any(is.na(datam[i,covariates]))&(datam[i,groupID]!="")
  }}



  for (i in 1:length(covariates))
  {if  (is.factor(new[,covariates[i]])) {new[,covariates[i]]=as.character(new[,covariates[i]])}
    if  (is.factor(datam[,covariates[i]])) {datam[,covariates[i]]=as.character(datam[,covariates[i]])}
    new[is.na(new[,covariates[i]]),covariates[i]]=""
    new=new[new[,covariates[i]]!="",]
    datam[is.na(datam[,covariates[i]]),covariates[i]]=""
    datam=datam[datam[,covariates[i]]!="",]
  }


  if (nrow(datam)==0) {data=new} else
  {data=rbind(datam, new)}

  dataevent=data[, c(IDID, eventcol)]
  data=data[!duplicated(data[, IDID]),]

  covnames=names(data)
  categorical=covnames[!covnames%in%c(IDID, eventcol, groupID)]
  categorical=categorical[categorical%in%covariates]
  Continuous= Continuous
  Continuous=Continuous[Continuous%in%names(data)]
  categorical=categorical[!categorical%in%Continuous]

  data$random_group[is.na(data$random_group)]=""
  planned.sample.size= planned.sample.size



  if (trial=="single-site")
  {categorical=categorical[!categorical%in%c("site")]}

  data$random_group[is.na(data$random_group)]=""
  planned.sample.size= planned.sample.size

  if (trial=="multi-site")
  {  categoricalx=c(categorical[!categorical%in%c("site")])
  for (i in 1:length(categoricalx))
  {interi=as.factor(as.character(paste(data$site, data[,categoricalx[i]], sep="-")))

  if (i==1) {inx=data.frame(interi)} else {inx=data.frame(inx, interi)}
  }
  inx=as.data.frame(inx)
  names(inx)=paste0("site-",categoricalx)
  data=cbind(data,inx)

  if (length(Continuous)>0)
  {
    nsite=rep(NA, nrow(data))
    nsite[data$site=="PBRC (1)"]=1
    nsite[data$site=="Kaiser (2)"]=2
    nsite[data$site=="Dana Farber (3)"]=3

    for (j in 1:length(Continuous))
    {sContinuous=nsite*data[,Continuous[j]]
    if (j==1) {dContinous=sContinuous} else
    {dContinous=cbind(dContinous, sContinuous)}
    }
    dContinous=as.data.frame(dContinous)
    names(dContinous)=paste0("site-", Continuous)
    data=cbind(data, dContinous)
    Continuous=c(Continuous, names(dContinous))
  }
  categorical=names(data)[-which(names(data)%in%c(IDID, eventcol, groupID, Continuous))]
  }



  datab=data


  group.level=as.factor(group.level)
  if (length(Continuous)<1)
  {
    data$random_group=
      FUN.BCAR(data,
               group.var = groupID,
               categorical.covariates =  categorical, group.level=group.level,
               planned.sample.size = planned.sample.size,
               pRA=pRA_full, tuning = .2, tuning2 = 1)

  } else
  {data$random_group=
    FUN.BCAR(data,
             group.var = groupID,
             categorical.covariates =  categorical, continuous.covariates = c(Continuous), group.level=group.level,
             planned.sample.size = planned.sample.size,
             pRA=pRA_full, tuning = .2, tuning2 = 1)
  }





  outdata0=outdata1=outdata=data
  outdata0=outdata[,c(IDID, eventcol, covariates[covariates%in%c("site", "sex")])]
  outdata1=outdata[,c(IDID, eventcol, covariates[!covariates%in%c("site", "sex")], groupID)]
  outdata1=outdata[,c(IDID, eventcol,                                              groupID)]
  outdata0=outdata[,c(IDID, eventcol)]
  #outdata1=outdata[,c(IDID, eventcol, covariates, groupID)]
  outdata1[, eventcol]=paste0("v2", substr(outdata1[, eventcol], 4, 50))

  for (i in 1:length(covariates))
  {wh.name=which(tolower(names(outdata0))==tolower(covariates[i]))
  names(outdata0)[wh.name]=covariates[i]
  }



  outdata1out=outdata1[outdata1$record_id==record_id,]
  #write.csv(outdata1out, paste("C:/Users/YangS/rand.out.", Sys.Date(), ".csv"), row.names=FALSE)

  newlyRandomized=NULL
  newlyRandomized=data[data[, IDID]%in%datab[, IDID][(is.na(datab$random_group))|(datab$random_group=="")],]
  newlyRandomizedout=newlyRandomized[,c(IDID, eventcol,                                              groupID)]
  newlyRandomizedout[, eventcol]=paste0("v2", substr(newlyRandomizedout[, eventcol], 4, 50))

  #write.csv(newlyRandomizedout, paste("C:/Users/YangS/rand.out.1.", Sys.Date(), ".csv"), row.names=FALSE)


  #redcap_write(newlyRandomizedout,redcap_uri=api_url, token=api_token)

  for (i in 1:( length(categorical)))
  { data[,categorical[i]]=as.factor(data[,categorical[i]])}

  out=vector("list", 1+length(categorical))
  data$`Assigned group`=rep("Number of subjects", nrow(data))
  for (i in 1:(1+length(categorical)))
  { dd=table(as.factor(data[,c("Assigned group", categorical)[i]]), factor(data$random_group, group.level))
  ddd= as.data.frame.matrix(dd)
  ddd$var=row.names(ddd)
  names(ddd)[names(ddd)=="var"]=c("Assigned group", categorical)[i]
  out[[i]]=ddd
  }

