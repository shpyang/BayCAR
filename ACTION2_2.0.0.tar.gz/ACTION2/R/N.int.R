#' Normal Distribution Integration Function
#'
#' Computes the product of (1 - CDF) for treatment groups multiplied by a
#' standard normal density function. This is used for numerical integration
#' to determine treatment superiority for continuous outcomes.
#'
#' @param x Numeric value at which to evaluate the function.
#' @param outdata A matrix or data frame where Row 1 is the control group.
#'   Column 4 must contain the Means and Column 5 must contain the SDs.
#'
#' @return A numeric value representing the integrand at point \code{x}.
#'
#' @examples
#' \dontrun{
#' # Example outdata: Row 1 = Control, Row 2 = Treatment
#' # Col 4: Mean, Col 5: SD
#' test_outdata <- matrix(c(0, 0, 0, 0.5, 0.1,
#'                          0, 0, 0, 0.6, 0.1),
#'                        nrow = 2, byrow = TRUE)
#'
#' integrate(f = N.int, lower = -Inf, upper = Inf, outdata = test_outdata)
#' }
#' @export
#'
#'
N.int <- function(x, outdata) {
  # Input validation
  if (!is.numeric(x)) {
    stop("Parameter 'x' must be numeric")
  }

  if (!is.matrix(outdata) && !is.data.frame(outdata)) {
    stop("Parameter 'outdata' must be a matrix or data frame")
  }

  if (nrow(outdata) < 2) {
    stop("Parameter 'outdata' must have at least 2 rows (control + treatment)")
  }

  if (ncol(outdata) < 5) {
    stop("Parameter 'outdata' must have at least 5 columns")
  }

  # Extract control group parameters (row 1)
  control_mean <- outdata[1, 4]
  control_sd <- outdata[1, 5]

  # Calculate product of (1 - CDF) for all treatment groups
  cdf_product <- 1

  for (i in 2:nrow(outdata)) {
    # Extract treatment group parameters
    treatment_mean <- outdata[i, 4]
    treatment_sd <- outdata[i, 5]

    # Calculate parameters for the difference distribution
    # Mean of (control - treatment) difference, normalized
    diff_mean <- (control_mean - treatment_mean) / treatment_sd

    # Standard deviation of the difference
    diff_sd <- control_sd / treatment_sd

    # Calculate 1 - P(control > treatment | x)
    # This is P(treatment >= control | x)
    prob_treatment_not_better <- 1 - stats::pnorm(x, mean = diff_mean, sd = diff_sd)

    # Multiply into the product
    if (i == 2) {
      cdf_product <- prob_treatment_not_better
    } else {
      cdf_product <- cdf_product * prob_treatment_not_better
    }
  }

  # Multiply by standard normal density
  standard_normal_density <- stats::dnorm(x)

  return(cdf_product * standard_normal_density)
}
