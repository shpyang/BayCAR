#' #' Shiny Application UI/Server for Adaptive Randomization
#'
#' Implements the user interface and server-side logic for the
#' Bayesian Adaptive Randomization and RDI dashboard.
#'
#' @param input Shiny input object.
#'
#' @param output Shiny output object.
#'
#' @import stats
#'
#' @import utils
#'
#' @import readxl
#'
#' @importFrom shiny observeEvent
#'
#' @importFrom shiny reactiveVal
#'
#' @importFrom shiny titlePanel
#'
#' @importFrom shiny validate
#'
#' @importFrom shiny sidebarLayout
#'
#' @importFrom shiny sidebarPanel
#'
#' @importFrom shiny uiOutput
#'
#' @importFrom shiny column
#'
#' @importFrom shiny sidebarLayout
#'
#' @importFrom shiny renderUI
#'
#' @importFrom shiny h3
#'
#' @importFrom shiny h4
#'
#' @importFrom shiny fluidPage
#'
#' @importFrom shiny fileInput
#'
#' @importFrom shiny checkboxInput
#'
#' @importFrom shiny selectInput
#'
#' @importFrom shiny numericInput
#'
#' @importFrom shiny mainPanel
#'
#' @importFrom shiny actionButton
#'
#' @importFrom shiny br
#'
#' @importFrom shiny HTML
#'
#' @importFrom shiny div
#'
#' @importFrom shiny br
#'
#' @importFrom shiny br
#'
#' @importFrom shiny downloadHandler
#'
#' @importFrom shiny textOutput
#'
#' @importFrom shiny downloadButton
#'
#' @import DT
#
#' @import redcapAPI
#'
#' @import REDCapR
#'
#' @examples
#'
#' myUI()
#'
#' @export

myUI2= function()
{  fluidPage(
  # Header Section - Orange looks great with white text
  div(
    style = "background-color: #f39c12; color: white; padding: 20px; margin-bottom: 20px; border-radius: 5px;",
    h2("Bayesian Covariate-Adjusted Response-Adaptive Randomization (BayCARA)",
       style = "margin: 0; font-weight: 400;")
  ),
  sidebarLayout(
    # Sidebar with a slider input
    sidebarPanel
    (column(12,
            h4(" "
               , style = "background-color: white; font-size: 25px; color: green;")),
      column(12,
             h4(" "
                , style = "background-color: white; font-size: 25px; color: green;")),
      column(6, textInput("record_id", "Subject ID", "")),

      column(12, selectInput("random_eligible", "Eligible? If No, then do not continue.",
                             c("Yes!", "Will ask...", ""),selected ="")),
      column(12,
             h4("STOP if this subject is not eligible!"
                , style = "background-color: white; font-size: 25px; color: red;")),

      column(12,
             h3("If there are subjects to be excluded, then upload the excluded subject file."
                , style = "background-color: white; font-size: 15px; color: brown;")),
      column(12, fileInput("excludedid",  ("Excluded subject file in .xlsx format"), accept = ".xlsx"),
             #       checkboxInput("header3", "Header", TRUE)
      ),

    ),
    # main panel
    mainPanel(
      tabsetPanel(  # <--- INSERT THIS
        tabPanel("Randomization", # <--- INSERT THIS
                 column(12,
                        h4("Click the 'Show' button to confirm the input values for the new data.
                \n Do not click the 'Action' button unless all the values have been confirmed."),
                        actionButton("show", "Show (might take a while ...)", style = "background-color: #f39c12; font-size: 25px; color: white;")),
                 column(12, dataTableOutput("tablenew")),
                 column(12, h3(uiOutput("noID1"))),
                 column(12, h3(uiOutput("missingRDI"))),
                 column(12, h3(uiOutput("needcov"))),
                 column(12, h3(uiOutput("noID2"))),
                 column(12, h3(uiOutput("noID3"))),
                 column(12, h3(uiOutput("noID4"))),
                 column(12, h3(uiOutput("wrong.ran"))),
                 column(12, h3(uiOutput("notnewID"))),
                 column(12, h3(uiOutput("missing.ran"))),

                 column(12, div(style = "background-color: lightgray; color: darkblue;", selectInput("display", "Display diagnostic tables?", c("No", "Yes"), selected ="No", width="100%",
                                                                                                     selectize = TRUE))),
                 column(12, h4("Click on the 'Action' button to run! The group assignments for the new subject(s) will be shown in a table with a green background (underneath the optional blue diagnosis tables) below. Othersise, there will be a warning message in red. Also, make sure to click on the download icon to backup."),
                        actionButton("action", "Action", style = "background-color: #27ae60; font-size: 30px; color: white;")),

                 column(12, dataTableOutput("table1")),
                 column(12, h3(uiOutput("noID5"))),

                 column(6, align="center", dataTableOutput("table2")),
                 column(6, align="center", dataTableOutput("table3")),
                 column(6, align="center", dataTableOutput("table4")),
                 column(6, align="center", dataTableOutput("table5")),
                 column(6, align="center", dataTableOutput("table6")),
                 column(6, align="center", dataTableOutput("table7")),
                 column(6, align="center", dataTableOutput("table8")),
                 column(6, align="center", dataTableOutput("table9")),
                 column(6, align="center", dataTableOutput("table10")),
                 column(6, align="center", dataTableOutput("table11")),
                 column(6, align="center", dataTableOutput("table12")),
                 column(6, align="center", dataTableOutput("table13")),
                 column(6, align="center", dataTableOutput("table14")),
                 column(6, align="center", dataTableOutput("table15")),
                 column(6, align="center", dataTableOutput("table16")),
                 column(6, align="center", dataTableOutput("table17")),
                 column(6, align="center", dataTableOutput("table18")),
                 column(6, align="center", dataTableOutput("table19")),
                 column(6, align="center", dataTableOutput("table20")),
                 column(12, align="center", dataTableOutput("table99")),
                 column(12, textOutput("display" )),
                 column(12, h3(textOutput(" "))),
                 column(12, h3(uiOutput("WNOnewlyRandomized"))),
                 br(),
                 column(12, align="center", dataTableOutput("table98")),
                 downloadButton("downloadData", "Download randomization data for the new subject(s)", style = "background-color: #3498db; font-size: 15px; color: white;"),
                 downloadButton("downloadDataC", "Download randomization data for ALL subjects", style = "background-color: #34495e; font-size: 15px; color: white;"),
        ), # <--- CLOSE THE FIRST TAB
        tabPanel("RDI Plot", # <--- NEW TAB FOR THE BOXPLOT
                 column(12, br()),
                 plotOutput("rdiBoxplot")
        )
      ) # <--- CLOSE THE tabsetPanel
    ) # <--- CLOSE THE mainPanel (This was missing in your snippet)
  ) # <--- CLOSE THE sidebarLayout
) # <--- CLOSE THE fluidPage
}

