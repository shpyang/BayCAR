#' Fetch Planned Treatment Schedules from REDCap
#'
#' Retrieves the planned chemotherapy regimen, cycle lengths, and doses for
#' each subject as defined in the study protocol within REDCap.
#'
#' @param api_url Character; the REDCap API endpoint URL.
#' @param api_token Character; the project-specific API token.
#' @param rfields Character vector of randomization/demographic fields.
#' @param sfields Character vector of chemotherapy schedule-specific fields.
#'
#' @return A data frame containing the planned treatment parameters and
#'   the identified regimen (e.g., FOLFOX, CAPEX).
#' @export
#'
#'
FUN.schedule= function(api_url, api_token, rfields, sfields)
{
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  rraann= redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(rfields), verbose=FALSE)
  rraa=as.data.frame(rraann$data)

  rraa=rraa[!rraa$record_id%in%c("S05-01-TEST", "S05-02-TEST", "S05-03-TEST", "A00-00-TEST", "S05-01-TEST"),]
  rraa$rDate=as.Date(rraa$random_date)
  rraa1=rraa[substr(toupper(rraa$redcap_event_name ),1,3)=="PPT", c(1,5,6,7)]
#  rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,9:14)]
  rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,8:13)]
  rraa2=rraa2[!is.na(rraa2$random_group),]

  rd=merge(rraa1, rraa2, by="record_id", all.y=TRUE)
  rd$dur=rd$random_chemo_duration
  #rd$rage=floor((rd$random_date-rd$dob)/365.25)
  #rd$age=rd$rage
  rd=rd[, -which(names(rd)%in%c("rage", "random_date"))]
  #rd$agee= round(as.Date(rd$rDate)-as.Date(rd$dob))/365.25

  rd=rd[!is.na(rd$rDate),]

  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  #rraa=read.csv("H:/WFH/ACTION2/data/ACTIONNCT05773144Bro-RandomizationCovaria_DATA_LABELS_2026-02-11_1106.mod.csv")
  #rraa=rraa[!rraa$record_id%in%c("S05-01-TEST", "S05-02-TEST", "S05-03-TEST", "A00-00-TEST", "S05-01-TEST"),]
  #rraa$rDate=as.Date(rraa$random_date, format="%m/%d/%Y")
  #rraa1=rraa[substr(toupper(rraa$redcap_event_name ),1,3)=="PPT", c(1,4,5)]
  #rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,6:11)]
  #rraa2=rraa2[!is.na(rraa2$random_group),]

  #rd=merge(rraa1, rraa2, by="record_id", all.y=TRUE)
  #rd$rage=floor(as.numeric(as.Date(rd$random_date, format="%m/%d/%Y") - as.Date(rd$dob, format="%m/%d/%Y"))/365.25)

  #rd$dur=rd$random_chemo_duration
  #rd$age=rd$rage
  #rd=rd[, -which(names(rd)%in%c("rage", "random_date"))]
  #rd=rd[!is.na(rd$rDate),]

  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################

  # Schedule
  sc0= redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(sfields), verbose=FALSE)
  sc=as.data.frame(sc0$data)

  sc=sc[, which(names(sc)%in%sfields)]

  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################

  #sc=read.csv("H:/WFH/ACTION2/data/ACTIONNCT05773144Bro-ChemoSchedule_DATA_2026-01-28_1426.csv")
  #table(sfields%in%names(sc))

  #sc=sc[, which(names(sc)%in%sfields)]

  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################

  ###############
  #sc=sc[substr(sc$redcap_event_name,1,3)=="int",]
  ###############
  sc=sc[!is.na(sc$spc_chemo_regimen___1),]


  sc=sc[sc$record_id%in%rd$record_id,]
  sc=sc=sc[!sc$record_id%in%c("S05-01-TEST", "S05-02-TEST", "S05-03-TEST", "A00-00-TEST", "S05-01-TEST"),]

  sc$cyc.OX=sc$spc_o_cyc              # How.many.cycles.of.Oxaliplatin.are.planned..
  sc$day.OX=sc$spc_o_cyclength        # What.is.the.planned.cycle.length.in.days.for.Oxaliplatin.......Count.number.of.days.between.cycles.to.get.this.number..with.the.day.chemotherapy.is.administered.as.the.first.day
  sc$dose.OX=sc$spc_o_dose            # What.is.the.planned.dose.of.Oxaliplatin.

  sc$cyc.FU=sc$spc_f_bolus_cyc        # How.many.cycles.of.5.fluorouracil.are.planned..
  sc$day.FU=sc$spc_f_bolus_cyclength  # What.is.the.planned.cycle.length.in.days.for.5.fluorouracil.......Count.number.of.days.between.cycles.to.get.this.number..with.the.day.chemotherapy.is.administered.as.the.first.day
  sc$dose.FU=sc$spc_f_bolus_dose      # What.is.the.planned.dose.of.5.fluorouracil.

  sc$cyc.FUc=sc$spc_f_cont_cyc        # How.many.cycles.of.5.fluorouracil.are.planned...1
  sc$day.FUc=sc$spc_f_cont_cyclength  # What.is.the.planned.cycle.length.in.days.for.5.fluorouracil.......Count.number.of.days.between.cycles.to.get.this.number..with.the.day.chemotherapy.is.administered.as.the.first.day.1
  sc$dose.FUc=sc$spc_f_cont_dose      # What.is.the.planned.dose.of.5.fluorouracil.Total.administered.dose.for.cycle


  sc$cyc.OX[is.na(sc$cyc.OX)]=sc$spc_cyc_a1[is.na(sc$cyc.OX)]              #
  sc$day.OX[is.na(sc$day.OX)]=sc$spc_cyclength_a1[is.na(sc$day.OX)]     #
  sc$dose.OX[is.na(sc$dose.OX)]=sc$spc_dose_a1[is.na(sc$dose.OX)]     #

  sc$cyc.FU[is.na(sc$cyc.FU)]=sc$spc_cyc_a2[is.na(sc$cyc.FU)]              #
  sc$day.FU[is.na(sc$day.FU)]=sc$spc_cyclength_a2[is.na(sc$day.FU)]     #
  sc$dose.FU[is.na(sc$dose.FU)]=sc$spc_dose_a2[is.na(sc$dose.FU)]     #

  sc$cyc.FUc[is.na(sc$cyc.FUc)]=sc$spc_cyc_a3[is.na(sc$cyc.FUc)]              #
  sc$day.FUc[is.na(sc$day.FUc)]=sc$spc_cyclength_a3[is.na(sc$day.FUc)]     #
  sc$dose.FUc[is.na(sc$dose.FUc)]=sc$spc_dose_a3[is.na(sc$dose.FUc)]     #


  sc$cyc.CAP=sc$spc_c_cyc             # How.many.cycles.of.Capecitabine.are.planned..
  sc$day.CAP=sc$spc_c_cyclength       # What.is.the.planned.cycle.length.in.days.for.Capecitabine.......Count.number.of.days.between.cycles.to.get.this.number..with.the.day.chemotherapy.is.administered.as.the.first.day
  sc$dose.CAP=sc$spc_c_dose           # What.is.the.planned.dose.of.Capecitabine.
  sc$regimen=NA
  sc$regimen[sc$spc_chemo_regimen___1==1]="FOLFOX"     # spc_chemo_regimen
  sc$regimen[sc$spc_chemo_regimen___2==1]="CAPEX"     # spc_chemo_regimen
  sc$regimen[sc$spc_chemo_regimen___3==1]="Other"     # spc_chemo_regimen

  sc$complete.=sc$planned_chemotherapy_schedule_complete

  sc[sc$cyc.OX!=sc$cyc.FU&(!is.na(sc$cyc.OX))&(!is.na(sc$cyc.FU)),]

  sc[sc$cyc.OX!=sc$cyc.CAP&(!is.na(sc$cyc.OX))&(!is.na(sc$cyc.CAP)),]



  sc$cyc.OX[sc$record_id=="S05-02-0056"]=8
  sc$cyc.OX[sc$record_id=="S05-02-0025"]=12

  sc=sc[,which(names(sc)%in%c("record_id", "cyc.OX", "day.OX", "dose.OX", "cyc.FU", "day.FU", "dose.FU", "cyc.FUc", "day.FUc", "dose.FUc",
                              "cyc.CAP", "day.CAP", "dose.CAP", "regimen", "complete."))]

  return(sc)
}
