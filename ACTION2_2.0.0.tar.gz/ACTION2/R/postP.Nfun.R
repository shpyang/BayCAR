#' Calculate Posterior Probabilities (Normal Model)
#'
#' Computes the probability that each treatment arm is the superior group
#' for continuous outcomes using numerical integration (\code{N.int}).
#'
#' @param tdata Data frame containing treatment assignments (\code{trt})
#'   and response data (\code{y}).
#' @param premu Numeric; prior mean(s).
#' @param presd Numeric; prior standard deviation(s).
#'
#' @return A numeric vector of normalized probabilities for group assignment. These
#' probabilities represent the belief that each group has the highest mean response.
#'
#' @details
#' This function implements Bayesian calculation for normally distributed data
#' with conjugate normal priors. The procedure involves:
#' \enumerate{
#'   \item Calculate sample statistics (mean, SD, sample size) for each treatment group
#'   \item Compute posterior distributions using conjugate normal-normal updating
#'   \item Use numerical integration to compute the probability that each group
#'         has the highest mean response
#'   \item Normalize probabilities and apply square root transformation for stabilization
#' }
#'
#' The square root transformation helps stabilize probabilities when differences
#' between groups are small.
#'
#' @examples
#' # Create sample data
#' set.seed(123)
#' tdata <- data.frame(
#'   gender = sample(c("female", "male"), 100, TRUE, c(0.5, 0.5)),
#'   age = sample(c("<=50", ">50"), 100, TRUE, c(0.5, 0.5)),
#'   stringsAsFactors = TRUE
#' )
#' tdata$trt <- sample(c("A", "B", "C"), 100, replace = TRUE)
#' tdata$y <- rnorm(100, mean = 3)
#'
#' # Calculate posterior probabilities
#' posterior_probs <- postP.Nfun(tdata, premu = 3.1, presd = 0.9)
#' print(posterior_probs)
#'
#' # Verify probabilities sum to 1
#' sum(posterior_probs)
#'
#' @export
postP.Nfun <- function(tdata, premu, presd) {
  # Input validation
  if (missing(tdata) || missing(premu) || missing(presd)) {
    stop("Parameters 'tdata', 'premu', and 'presd' are required")
  }

  if (!is.data.frame(tdata)) {
    stop("Parameter 'tdata' must be a data frame")
  }

  if (!"trt" %in% names(tdata)) {
    stop("Data frame 'tdata' must contain a 'trt' column")
  }

  if (!"y" %in% names(tdata)) {
    stop("Data frame 'tdata' must contain a 'y' column")
  }

  if (!is.numeric(premu) || !is.numeric(presd)) {
    stop("Parameters 'premu' and 'presd' must be numeric")
  }

  if (any(presd <= 0)) {
    stop("All values in 'presd' must be positive")
  }

  # Get unique treatment groups and count
  treatment_groups <- sort(unique(tdata$trt))
  n_treatments <- length(treatment_groups)

  if (n_treatments < 2) {
    stop("Data must contain at least 2 treatment groups")
  }

  # Recycle scalar parameters to match number of treatments
  if (length(premu) == 1) {
    premu <- rep(premu, n_treatments)
  }
  if (length(presd) == 1) {
    presd <- rep(presd, n_treatments)
  }

  # Check parameter lengths match number of treatments
  if (length(premu) != n_treatments || length(presd) != n_treatments) {
    stop("Length of 'premu' and 'presd' must match number of treatment groups or be 1")
  }

  # Initialize results matrix
  # Columns: sample_mean, sample_sd, sample_size, posterior_mean, posterior_sd
  results_matrix <- matrix(NA, nrow = n_treatments, ncol = 5)
  rownames(results_matrix) <- treatment_groups

  # Calculate sample statistics and posterior distributions for each treatment
  for (i in 1:n_treatments) {
    current_group <- treatment_groups[i]
    group_responses <- tdata$y[tdata$trt == current_group]

    # Remove NA values for calculations
    valid_responses <- group_responses[!is.na(group_responses)]
    n_valid <- length(valid_responses)

    if (n_valid > 0) {
      sample_mean <- mean(valid_responses)
      sample_sd <- ifelse(n_valid > 1, stats::sd(valid_responses), 0)
    } else {
      sample_mean <- NA
      sample_sd <- NA
      n_valid <- 0
    }

    results_matrix[i, 1] <- sample_mean
    results_matrix[i, 2] <- sample_sd
    results_matrix[i, 3] <- n_valid

    # Calculate posterior distribution if we have data
    if (n_valid > 0 && !is.na(sample_mean)) {
      posterior <- post.fun(
        premu = premu[i],
        presd = presd[i],
        mdata = sample_mean,
        sddata = sample_sd,
        sizes = n_valid
      )
      results_matrix[i, 4] <- posterior$posterior_means
      results_matrix[i, 5] <- posterior$posterior_sds
    } else {
      # Use prior if no data available
      results_matrix[i, 4] <- premu[i]
      results_matrix[i, 5] <- presd[i]
    }
  }

  # Calculate posterior probabilities using numerical integration
  posterior_probs <- numeric(n_treatments)

  for (i in 1:n_treatments) {
    # Create comparison matrix with current group first
    comparison_matrix <- rbind(
      results_matrix[i, , drop = FALSE],  # Current group
      results_matrix[-i, , drop = FALSE]  # All other groups
    )

    # Compute probability that current group is best
    integrated_prob <- stats::integrate(
      f = N.int,
      lower = -Inf,
      upper = Inf,
      outdata = comparison_matrix
    )$value

    posterior_probs[i] <- integrated_prob
  }

  # Apply square root transformation and normalize
  # This helps stabilize probabilities when differences are small
  transformed_probs <- sqrt(posterior_probs / sum(posterior_probs))

  # Handle edge case where all probabilities are zero
  if (all(transformed_probs == 0)) {
    transformed_probs <- rep(1 / n_treatments, n_treatments)
    warning("All posterior probabilities were zero. Using uniform distribution as fallback.")
  }

  # Normalize final probabilities
  final_probs <- transformed_probs / sum(transformed_probs)

  # Add treatment group names
  names(final_probs) <- treatment_groups

  return(final_probs)
}
