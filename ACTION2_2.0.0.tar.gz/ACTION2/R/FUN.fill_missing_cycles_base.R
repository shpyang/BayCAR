#' Fill Gaps in Longitudinal Chemotherapy Data
#'
#' Identifies missing chemotherapy cycles and inserts zero-dose records.
#'
#' @param data Data frame of chemotherapy records.
#' @param cycle_col Character name for the cycle count column.
#' @param adm_col Character name for the administered dose column.
#' @param days_col Character name for the cycle duration column.
#' @export
#'
#'
FUN.fill_missing_cycles_base <- function(data, cycle_col, adm_col, days_col) {
  # Convert arguments to character column names
  cycle_col <- as.character( (cycle_col))
  adm_col   <- as.character( (adm_col))

  # Ensure correct data types
  #data$Current.Cycle.Number <- as.integer(data$Current.Cycle.Number)
  #data[,cycle_col] <- as.integer(data[,cycle_col])
  #data[,adm_col] <- as.numeric(data[,adm_col])

  # Split data by record_id
  split_data <- split(data, data$record_id)

  result_list <- list()
  uids=names(split_data)


  for (id in uids) {#print(id)
    sub_df <- split_data[[id]]

    max_cycle <- sub_df[,cycle_col][1]
    existing_cycles <- sub_df$Current.Cycle.Number
    full_cycles <- 1:max_cycle

    missing_cycles <- setdiff(full_cycles, existing_cycles)


    if (length(missing_cycles) > 0 & sub_df[1, cycle_col] >0) {
      copy_columes=c( "record_id", "cyc.OX", "day.OX", "dose.OX", "cyc.FU", "day.FU", "dose.FU", "cyc.FUc", "day.FUc", "dose.FUc", "cyc.CAP", "day.CAP", "dose.CAP",
                      "regimen", "rDate" )               #"random_chemo_started",

      diff_columes=  names(sub_df) [ -which(names(sub_df)%in%copy_columes)]

      dfc1=sub_df[, copy_columes]
      df1=dfc1[rep(1, times= max_cycle), ]
      df1$Current.Cycle.Number=1:max_cycle


      df2= sub_df[, diff_columes]

      mg = merge(df1, df2, by="Current.Cycle.Number", all=TRUE)
      mg = mg[order(mg$Current.Cycle.Number), ]

      if (!all(is.na(mg[,"OXadm"]))  &  ( ( as.numeric(Sys.Date()-df2$Date.chemo[1]))> (df1$cyc.OX[1]*df1$day.OX[1])) ) {mg[missing_cycles, "OXadm"]=0}
      if (!all(is.na(mg[,"FUadm"]))  &  ( ( as.numeric(Sys.Date()-df2$Date.chemo[1]))> (df1$cyc.OX[1]*df1$day.OX[1])) ) {mg[missing_cycles, "FUadm"]=0}
      if (!all(is.na(mg[,"FUcadm"]))  &  ( ( as.numeric(Sys.Date()-df2$Date.chemo[1]))> (df1$cyc.OX[1]*df1$day.OX[1])) ) {mg[missing_cycles, "FUcadm"]=0}
      if (!all(is.na(mg[,"CAPadm"]))  &  ( ( as.numeric(Sys.Date()-df2$Date.chemo[1]))> (df1$cyc.OX[1]*df1$day.OX[1])) ) {mg[missing_cycles, "CAPadm"]=0}
      #     if (!all(is.na(mg[,"FUadm"]))){mg[missing_cycles, "FUadm"]=0}
      #     if (!all(is.na(mg[,"FUcadm"]))){mg[missing_cycles, "FUcadm"]=0}
      #     if (!all(is.na(mg[,"CAPadm"]))){mg[missing_cycles, "CAPadm"]=0}
      #      mg[is.na(mg[,adm_col]),adm_col]=0
      #      mg[is.na(mg[,adm_col]),"FUadm"]=0
      #      mg[is.na(mg[,adm_col]),"FUcadm"l]=0
      #      mg[is.na(mg[,adm_col]),]=0

      mg[,"complete."]=mg[,"complete.."]=mg[,"complete..."]=2
      if (sum(diff(is.na(mg$Date.chemo)))>1) {print ("Check middle missing cycles!")}

      mcyc=max(existing_cycles, na.rm=TRUE)

      mg$Date.chemo[(mcyc+1):nrow(mg)]=as.Date( as.Date(mg$Date.chemo[mcyc], format = "%m/%d/%Y")+ mg[1, days_col] * c(1:(nrow(mg)-mcyc)))
      sub_df=mg
    }

    result_list[[id]] <- sub_df
  }


  # Combine all groups
  result_df <- do.call(rbind, result_list)
  rownames(result_df) <- NULL
  return(result_df)
}
