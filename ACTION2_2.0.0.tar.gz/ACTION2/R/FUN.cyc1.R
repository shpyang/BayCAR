#' Fetch REDCap Chemotherapy Records
#'
#' Connects to the REDCap API to retrieve and clean chemotherapy cycle data.
#'
#' @param api_url Character URL for the REDCap API.
#' @param api_token Character API token.
#' @param rfields Vector of randomization fields.
#' @param mfields Vector of chemotherapy-specific fields (use cfields for cyc1).
#' @export
#'
#'
FUN.cyc1=function(api_url, api_token, rfields, cfields)
{ ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  rraann= redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(rfields), verbose=FALSE)
  rraa=as.data.frame(rraann$data)

  rraa=rraa[!rraa$record_id%in%c("S05-01-TEST", "S05-02-TEST", "S05-03-TEST", "A00-00-TEST", "S05-01-TEST"),]
  rraa$rDate=as.Date(rraa$random_date)
  rraa1=rraa[substr(toupper(rraa$redcap_event_name ),1,3)=="PPT", c(1,5,6,7)]
  #  rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,9:14)]
  rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,8:13)]
  rraa2=rraa2[!is.na(rraa2$random_group),]

  rd=merge(rraa1, rraa2, by="record_id", all.y=TRUE)
  rd$dur=rd$random_chemo_duration
  #rd$rage=floor((rd$random_date-rd$dob)/365.25)
  #rd$age=rd$rage
  rd=rd[, -which(names(rd)%in%c("rage", "random_date"))]
  #rd$agee= round(as.Date(rd$rDate)-as.Date(rd$dob))/365.25

  rd=rd[!is.na(rd$rDate),]
  ######################################## cyc1 ########################################
  ######################################## cyc1 ########################################
  ######################################## cyc1 ########################################
  ccyycc1= redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(cfields), verbose=FALSE)
  cy1=as.data.frame(ccyycc1$data)
  ######################################## cyc1 ########################################
  ######################################## cyc1 ########################################
  ######################################## cyc1 ########################################

  #cy1=read.csv("H:/WFH/ACTION2/data/ACTIONNCT05773144Bro-ChemoCycle1_DATA_2026-01-28_1427.csv")

  cy1=cy1[substr(cy1$redcap_event_name,1,3)=="int",]
  cy1=cy1[cy1$record_id%in%rd$record_id,]


  cy1$OXadm=cy1$chemo_bl_doseadmin_o                   #Dose.administered

  cy1$FUadm=cy1$chemo_bl_doseadmin_f_bolus             #Dose.administered.1

  cy1$FUcadm=cy1$chemo_bl_doseadmin_f_cont             #Dose.administeredTotal.administered.dose.for.cycle

  cy1$CAPadm=cy1$chemo_bl_doseadmin_c                    #Dose.admini


  cy1$OXadm[is.na(cy1$OXadm)]=cy1$chemo_bl_doseadmin_a1_plan[is.na(cy1$OXadm)]
  cy1$FUadm[is.na(cy1$FUadm)]=cy1$chemo_bl_doseadmin_a2_plan[is.na(cy1$FUadm)]
  cy1$FUcadm[is.na(cy1$FUcadm)]=cy1$chemo_bl_doseadmin_a3_plan[is.na(cy1$FUcadm)]



  cy1$Date.cy1=cy1$chemo_bl_date                      #Date.Chemotherapy.Administered

  cy1$complete..=cy1$chemotherapy_baseline_complete                      #Date.Chemotherapy.Administered


  cy1=cy1[, which(names(cy1)%in%c("record_id", "OXadm", "FUadm", "FUcadm","CAPadm",  "Date.cy1", "complete.."))]

  return(cy1)

}
