#' Execute Full RDI Extraction Pipeline
#'
#' Orchestrates the end-to-end process of fetching data from REDCap,
#' merging schedules with administered doses, filling missing cycles,
#' and calculating Relative Dose Intensity (RDI).
#'
#' @return A list containing the final RDI results and processed data frames.
#'
#' @details
#' The function hard-codes specific REDCap fields (rfields, efields, sfields, mfields)
#' and executes the sequence: FUN.schedule -> FUN.cyc1 -> FUN.cm -> FUN.MMM.
#' It includes manual data corrections for specific record IDs.
#'
#' @export
#'
#'
FUN.Extract_RDI=function()
{

rfields=c("record_id", "random_age", "random_chemo_duration", "random_fluoropyrimidine",
            "random_chemo_started", "random_date", "random_group", "sex", "age", "dob")

efields=c("record_id", "ipd_status")


sfields=c("record_id", "spc_o_cyc", "spc_o_cyclength", "spc_o_dose",
          "spc_f_bolus_cyc", "spc_f_bolus_cyclength", "spc_f_bolus_dose",
          "spc_f_cont_cyc", "spc_f_cont_cyclength", "spc_f_cont_dose",
          "spc_c_cyc", "spc_c_cyclength", "spc_c_dose", "spc_chemo_regimen",
          "planned_chemotherapy_schedule_complete",
          "spc_cyc_a1", "spc_cyclength_a1", "spc_dose_a1",
          "spc_cyc_a2", "spc_cyclength_a2", "spc_dose_a2",
          "spc_cyc_a3", "spc_cyclength_a3", "spc_dose_a3",
          "spc_chemo_regimen___1",
          "spc_chemo_regimen___2",
          "spc_chemo_regimen___3")

cfields=c("record_id", "chemo_bl_doseadmin_o", "chemo_bl_doseadmin_f_bolus", "chemo_bl_doseadmin_f_cont", "chemo_bl_doseadmin_c",
          "chemo_bl_doseadmin_a1", "chemo_bl_date", "chemotherapy_baseline_complete",
          "chemo_bl_doseadmin_a1_plan", "chemo_bl_doseadmin_a2_plan", "chemo_bl_doseadmin_a3_plan")

mfields=c("record_id", "chemo_doseadmin_o", "chemo_doseadmin_f_bolus", "chemo_doseadmin_f_cont", "chemo_doseadmin_c", "chemo_date",
          "chemo_cyc", "chemotherapy_complete", "chemo_doseadmin_a1",
          "chemo_doseadmin_a1_plan", "chemo_doseadmin_a2_plan", "chemo_doseadmin_a3_plan",
          "bl_earlyterm", "bl_earlyterm_tox_reason___1", "bl_earlyterm_tox_reason___5",
          "bl_earlyterm_tox_reason___2", "bl_earlyterm_tox_reason___99", "bl_earlyterm_tox_reason_o" )


print("Extracting schedule data...")
sc=FUN.schedule(api_url, api_token, rfields, sfields)
sc[1:3,]


print("Extracting cycle 1 data...")
cy1=FUN.cyc1(api_url, api_token, rfields, cfields)
cy1[1:3,]


print("Extracting all cycles data...")
cm=FUN.cm(api_url, api_token, rfields, mfields)
cm[1:3,]

# Check this out for missing values;
#cm$mm=is.na(cm[,2])+is.na(cm[,3])+is.na(cm[,4])+is.na(cm[,5])
#cm4=cm[cm$mm==4,]

MMMM=FUN.MMM(api_url, api_token, rfields, sc, cy1, cm)

# making manual corrections
MMMM$cyc.OX[MMMM$record_id=="S05-02-0056"]=0
MMMM$cyc.OX[MMMM$record_id=="S05-02-0025"]=6
MMMM$cyc.OX[MMMM$record_id=="S05-02-0025"]=6

MMMM$RDI_OX=MMMM$RDI_FU=MMMM$RDI_FUc=MMMM$RDI_CAP=NA

cycle_col="cyc.OX"; adm_col= "OXadm"; days_col= "day.OX"
MMM =FUN.fill_missing_cycles_base(MMMM, "cyc.OX", "OXadm", "day.OX")

RDIs=FUN.RDI.table(MMM)





# Completed
#EOS=read.csv("H:/WFH/ACTION2/data/ACTIONNCT05773144Bro-StudyComplete_DATA_LABELS_2026-02-11_1417.csv")
EEOS= redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=efields, verbose=FALSE)
EOS=as.data.frame(EEOS$data)

EOS=EOS[!is.na(EOS$ipd_status),]

EOS=EOS[EOS$ipd_status=="C",]

#dropped.ID=EOS$record_id[!is.na(EOS$Status)&EOS$Status=="Dropped"]
#dropped.ID
#table(EOS$Status)
#EOS=EOS[EOS$Status!="",]
#EOS=EOS[EOS$Status!="Dropped",]

EOS=EOS[EOS$record_id !="S05-02-0016",]    # dropout per Lu - For Patient S05-02-0016, S05-02-0012, and S05-02-0015, these patients withdrew from the study.


completed.IDs=sort(unique(EOS$record_id))

CRDIs=RDIs[RDIs$record_id%in%completed.IDs,]

boxplot(CRDIs$RDI~CRDIs$random_group, xlab="Group", ylab="RDI")
aggregate(CRDIs$RDI, list(CRDIs$random_group), FUN="mean")

table(CRDIs$random_group)

outRDI=CRDIs[, c("record_id", "random_group", "RDI")]

return(list(outRDI, CRDIs, MMM))
}
