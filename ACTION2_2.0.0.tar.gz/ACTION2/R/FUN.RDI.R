#' Individual Relative Dose Intensity Calculation
#'
#' Computes subject-level RDI by comparing administered vs. planned doses.
#'
#' @param data Data frame with subject dosing
#' @param ddose Column name for administered dose
#' @param ddur Column name for cycle duration
#' @param dcyc Column name for planned cycle count
#' @param pdose Column name for planned dose per cycle
#' @param outrdi Name for the new RDI column
#' @export
#'
#'
FUN.RDI=function(data, ddose, ddur, dcyc, pdose, outrdi)
{uids=sort(unique(data$record_id))

for (i in 1:length(uids))
{
  datai=data[data$record_id==uids[i],]
  datai=datai[!is.na(datai$Current.Cycle.Number),]

  datai[is.na(datai[,ddose]),ddose]=0

  #print(paste(i, uids[i], nrow(datai)))

  #if (nrow(datai)==0) {print(uids[i])}
  datai=datai[datai$Current.Cycle.Number<=datai[1,dcyc],]

  if (nrow(datai)>0)

  {
    datai=datai[order(datai$Current.Cycle.Number),]

    ######
    ######
    ######
    ######
    ######
    ######
    ######

    # This is to check if the order of cycle and date are consistent
    ######

    if (any(order(datai$Current.Cycle.Number)!=order(datai$Date.chemo))) {print (paste0("Check this id for cycle and date consistency: ", uids[i]))}


    datai=datai[order(datai$Date.chemo),]
    datai=datai[datai$Current.Cycle.Number<=datai[1,dcyc],]

    ddi1=sum(datai[,ddose])
    ddi2=as.numeric(as.Date(datai$Date.chemo)[nrow(datai)]-as.Date(datai$Date.chemo)[1])+datai[1,ddur]
    ddi=ddi1/ddi2

    sdi1=datai[1,pdose]*datai[1,dcyc]
    sdi2=datai[1,ddur]*datai[1,dcyc]
    sdi=sdi1/sdi2

    rdi=rep(t(ddi/sdi), nrow(datai))
  }
  if (i==1) {out=data.frame(record_id=uids[i], outrdi=rdi)} else {out=rbind(out, data.frame(record_id=uids[i], outrdi=rdi))}
}
names(out)[2]=outrdi
return(out)
}
