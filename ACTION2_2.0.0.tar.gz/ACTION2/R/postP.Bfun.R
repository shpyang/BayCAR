#' Calculate Posterior Probabilities (Beta-Binomial Model)
#'
#' Computes the probability that each treatment arm is the best group
#' for binary outcomes using a Jeffreys prior and numerical integration (\code{B.int}).
#'
#' @param frq Numeric vector of observed success frequencies for each group.
#'
#' @return A numeric vector of normalized posterior probabilities. These probabilities
#' represent the belief that each group is the best treatment option.
#'
#' @details
#' This function implements Bayesian calculation for binomial data with Beta priors.
#' For each treatment group i, it computes:
#' \deqn{P(\text{group i is best}) = \int_0^1 \left[\prod_{j \neq i} P(\theta_j < \theta_i)\right] p(\theta_i) d\theta_i}
#' where \eqn{\theta_i} follows a Beta distribution with parameters based on the
#' observed frequencies and a Jeffreys prior (Beta(0.5, 0.5)).
#'
#' The function handles edge cases where all frequencies are zero by adding a
#' small constant to avoid numerical issues.
#'
#' @examples
#' # Example with different response frequencies
#' frequencies <- c(20, 30, 50)  # 20, 30, 50 responses in three groups
#' posterior_probs <- postP.Bfun(frequencies)
#' print(posterior_probs)
#'
#' # The probabilities sum to 1
#' sum(posterior_probs)
#'
#' # Example with all zeros (edge case)
#' zero_frequencies <- c(0, 0, 0)
#' posterior_probs_zero <- postP.Bfun(zero_frequencies)
#' print(posterior_probs_zero)
#'
#' @export
postP.Bfun <- function(frq) {
  # Input validation
  if (missing(frq)) {
    stop("Parameter 'frq' is required")
  }

  if (!is.numeric(frq)) {
    stop("Parameter 'frq' must be a numeric vector")
  }

  if (any(frq < 0)) {
    stop("All frequencies in 'frq' must be non-negative")
  }

  n_groups <- length(frq)

  if (n_groups < 2) {
    stop("Parameter 'frq' must contain at least 2 groups")
  }

  # Handle edge case where all frequencies are zero
  # Add 1 to all frequencies to avoid numerical issues with Jeffreys prior
  if (all(frq == 0)) {
    frq <- frq + 1
  }

  # Initialize vector to store posterior probabilities
  posterior_probs <- numeric(n_groups)

  # Calculate posterior probability for each group
  for (i in 1:n_groups) {
    # Create circular shifted data for comparison
    # This puts the current group first and others follow
    shifted_data <- c(frq, frq)

    # Current group data (decision group)
    decision_data <- shifted_data[i]

    # Comparison groups data (all other groups)
    comparison_data <- shifted_data[(i + 1):(i + n_groups - 1)]

    # Calculate posterior probability using numerical integration
    # Uses Jeffreys prior (Beta(0.5, 0.5)) for binomial data
    integrated_prob <- stats::integrate(
      f = B.int,
      lower = 0,
      upper = 1,
      ddata = decision_data,
      cdata = comparison_data,
      constant = 0.5,
      rel.tol = .Machine$double.eps^0.5
    )$value

    posterior_probs[i] <- integrated_prob
  }

  # Normalize probabilities to sum to 1
  normalized_probs <- posterior_probs / sum(posterior_probs)

  # Handle edge case where all probabilities are zero (should not occur with above handling)
  if (all(normalized_probs == 0)) {
    normalized_probs <- rep(1 / n_groups, n_groups)
    warning("All posterior probabilities were zero. Using uniform distribution as fallback.")
  }

  return(normalized_probs)
}
