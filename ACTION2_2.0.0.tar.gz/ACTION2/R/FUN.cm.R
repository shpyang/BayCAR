#' Fetch REDCap Chemotherapy Administration Records
#'
#' Connects to the REDCap API to retrieve longitudinal chemotherapy dose
#' administration data. It cleans record IDs and formats chemotherapy dates.
#'
#' @param api_url Character; the REDCap API endpoint URL.
#' @param api_token Character; the project-specific API token.
#' @param rfields Character vector of randomization/demographic fields to fetch.
#' @param mfields Character vector of chemotherapy-specific administration fields.
#'
#' @return A data frame containing cleaned chemotherapy administration records
#'   with standardized column names (OXadm, FUadm, etc.).
#' @export
#'
#'
FUN.cm=function(api_url, api_token, rfields, mfields)
{
  ######################################## Schedule ########################################
  ######################################## Schedule ########################################
  rraann= redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(rfields), verbose=FALSE)
  rraa=as.data.frame(rraann$data)

  rraa=rraa[!rraa$record_id%in%c("S05-01-TEST", "S05-02-TEST", "S05-03-TEST", "A00-00-TEST", "S05-01-TEST"),]
  rraa$rDate=as.Date(rraa$random_date)
  rraa1=rraa[substr(toupper(rraa$redcap_event_name ),1,3)=="PPT", c(1,5,6,7)]
  #  rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,9:14)]
  rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,8:13)]
  rraa2=rraa2[!is.na(rraa2$random_group),]

  rd=merge(rraa1, rraa2, by="record_id", all.y=TRUE)
  rd$dur=rd$random_chemo_duration
  #rd$rage=floor((rd$random_date-rd$dob)/365.25)
  #rd$age=rd$rage
  rd=rd[, -which(names(rd)%in%c("rage", "random_date"))]
  #rd$agee= round(as.Date(rd$rDate)-as.Date(rd$dob))/365.25

  rd=rd[!is.na(rd$rDate),]

  ######################################## chemo ########################################
  ######################################## chemo ########################################
  ######################################## chemo ########################################

  cm0= redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(mfields), verbose=FALSE)
  cm=as.data.frame(cm0$data)
######################################## chemo ########################################
######################################## chemo ########################################
######################################## chemo ########################################
#cm=read.csv("H:/WFH/ACTION2/data/ACTIONNCT05773144Bro-Chemos_DATA_2026-02-24_1008_tox questions.csv")

cm[cm$bl_earlyterm==1&(!is.na(cm$bl_earlyterm)),]

changed=cm[cm$chemo_same_plan==0&(!is.na(cm$chemo_same_plan)),]

cm=cm[substr(cm$redcap_event_name,1,3)=="int",]
cm=cm[cm$record_id%in%rd$record_id,]
cm=cm[!is.na(cm$chemo_date),]
cm=cm[as.character(cm$chemo_date)!="",]

cm[cm$record_id=="S05-02-0025"&cm$chemo_cyc ==5&(!is.na(cm$chemo_cyc)),]$chemo_date = "2024-12-03"
#cm[cm$record_id=="S05-02-0025"&cm$chemo_cyc ==5&(!is.na(cm$chemo_cyc)),]$chemo_date = "12/3/2024"
cm[cm$record_id=="S05-01-0016"&cm$chemo_cyc ==3&(!is.na(cm$chemo_cyc)),]$chemo_date = "2024-05-28"
#cm[cm$record_id=="S05-01-0016"&cm$chemo_cyc ==3&(!is.na(cm$chemo_cyc)),]$chemo_date = "5/28/2024"

##################################cm[cm$record_id=="S05-01-0038"&cm$chemo_cyc ==8&(!is.na(cm$chemo_cyc)),]$chemo_date = "2025-08-14"
cm$chemo_doseadmin_a1_plan[cm$record_id=="A00-09-3322"]=cm$chemo_doseadmin_a1[cm$record_id=="A00-09-3322"]
cm$chemo_cyc[cm$record_id=="S05-02-0035"&as.character(cm$chemo_date)=="2025-03-25"&(!is.na(cm$chemo_date))&(!is.na(cm$record_id))]=4


cm$OXadm=cm$chemo_doseadmin_o                 # Dose.administered
cm$FUadm=cm$chemo_doseadmin_f_bolus           # Dose.administered.1
cm$FUcadm=cm$chemo_doseadmin_f_cont           # Dose.administeredTotal.administered.dose.for.cycle  #Dose.administered.2
cm$CAPadm=cm$chemo_doseadmin_c                # Dose.administeredTotal.dose.per.day   #Dose.administered.3

cm$OXadm[is.na(cm$OXadm)]=cm$chemo_doseadmin_a1_plan[is.na(cm$OXadm)]                # Dose.administered
cm$FUadm[is.na(cm$FUadm)]=cm$chemo_doseadmin_a2_plan[is.na(cm$FUadm)]                # Dose.administered
cm$FUcadm[is.na(cm$FUcadm)]=cm$chemo_doseadmin_a3_plan[is.na(cm$FUcadm)]                # Dose.administered

cm$Date.cm=cm$chemo_date                      # Date.cmtherapy.Administered
cm$complete...=cm$chemotherapy_complete                   # Date.cmtherapy.Administered
cm$Current.Cycle.Number = cm$chemo_cyc

cm=cm[, which(names(cm)%in%c("record_id", "OXadm", "FUadm", "FUcadm", "CAPadm", "Date.cm", "complete...", "Current.Cycle.Number" ))]

cmrsum=rowSums(is.na(cm))
cm=cm[which(cmrsum < (dim(cm)[[2]]-1)), ]


return(cm)
}
