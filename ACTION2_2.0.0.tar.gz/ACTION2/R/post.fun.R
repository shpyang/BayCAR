#' Calculate Normal-Normal Posterior Parameters
#'
#' Performs Bayesian conjugate updating for normal distributions. It takes
#' prior means/SDs and observed data to compute posterior distribution parameters.
#'
#' @param premu Numeric; prior mean(s).
#' @param presd Numeric; prior standard deviation(s).
#' @param mdata Numeric vector of observed sample means.
#' @param sddata Numeric vector of observed sample standard deviations.
#' @param sizes Numeric vector of group sample sizes.
#'
#' @return A list containing \code{posterior_means} and \code{posterior_sds}.
#'
#' @details
#' This function implements Bayesian conjugate updating for the normal-normal model.
#' The posterior parameters are calculated as:
#'
#' \deqn{\mu_{post} = \frac{\mu_{prior}/\sigma_{prior}^2 + n\bar{x}/\sigma_{data}^2}{1/\sigma_{prior}^2 + n/\sigma_{data}^2}}
#' \deqn{\sigma_{post} = \sqrt{\frac{1}{1/\sigma_{prior}^2 + n/\sigma_{data}^2}}}
#'
#' where:
#' \itemize{
#'   \item \eqn{\mu_{prior}}, \eqn{\sigma_{prior}}: Prior mean and standard deviation
#'   \item \eqn{\bar{x}}, \eqn{\sigma_{data}}: Sample mean and standard deviation
#'   \item \eqn{n}: Sample size
#' }
#'
#' @examples
#' # Example with multiple groups
#' posterior_params <- post.fun(
#'   premu = c(3, 3, 3),      # Prior means (same for all groups)
#'   presd = c(1, 1, 1),      # Prior standard deviations
#'   mdata = c(3.1, 3.2, 3.3), # Observed sample means
#'   sddata = c(1, 1, 1),     # Observed sample standard deviations
#'   sizes = c(20, 30, 25)    # Sample sizes
#' )
#'
#' print(posterior_params)
#'
#' # Example with scalar priors (same prior for all groups)
#' posterior_params2 <- post.fun(
#'   premu = 3,               # Same prior mean for all groups
#'   presd = 1,               # Same prior SD for all groups
#'   mdata = c(3.1, 3.2, 3.3),
#'   sddata = c(1, 1, 1),
#'   sizes = c(20, 30, 25)
#' )
#'
#' print(posterior_params2)
#'
#' @export
#'
#'
post.fun <- function(premu, presd, mdata, sddata, sizes) {
  # Input validation
  if (missing(premu) || missing(presd) || missing(mdata) || missing(sddata) || missing(sizes)) {
    stop("All parameters (premu, presd, mdata, sddata, sizes) are required")
  }

  if (!is.numeric(premu) || !is.numeric(presd) ||
      !is.numeric(mdata) || !is.numeric(sddata) || !is.numeric(sizes)) {
    stop("All parameters must be numeric")
  }

  n_groups <- length(mdata)

  # Recycle scalar parameters to match number of groups
  if (length(premu) == 1) {
    premu <- rep(premu, n_groups)
  }
  if (length(presd) == 1) {
    presd <- rep(presd, n_groups)
  }

  # Check parameter lengths match
  if (length(premu) != n_groups || length(presd) != n_groups ||
      length(sddata) != n_groups || length(sizes) != n_groups) {
    stop("All parameter vectors must have the same length or be scalar")
  }

  # Check for invalid values
  if (any(presd <= 0) || any(sddata <= 0) || any(sizes <= 0)) {
    stop("presd, sddata, and sizes must be positive values")
  }

  # Calculate posterior parameters using Bayesian conjugate updating
  # Posterior mean: weighted average of prior and data, weighted by precision
  prior_precision <- 1 / (presd^2)
  data_precision <- sizes / (sddata^2)

  posterior_means <- (premu * prior_precision + mdata * data_precision) /
    (prior_precision + data_precision)

  # Posterior standard deviation: square root of posterior precision
  posterior_sds <- sqrt(1 / (prior_precision + data_precision))

  # Return results as a named list
  return(list(
    posterior_means = posterior_means,
    posterior_sds = posterior_sds
  ))
}
