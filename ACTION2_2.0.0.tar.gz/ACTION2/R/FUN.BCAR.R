#' Bayesian Covariate-Adaptive and Response-Adaptive Randomization (BCAR)
#'
#' The primary engine for trial randomization, balancing covariates while
#' adapting to treatment response.
#'
#' @param data A data frame that contains the covariates to be randomized.
#' @param group.var The name of the grouping variable (default is "group").
#' @param categorical.covariates A list of categorical covariates to be balanced.
#' @param continuous.covariates A list of continuous covariates to be balanced.
#' @param group.level A list of all potential group IDs (e.g., c("A", "B")).
#' @param ratio The assignment ratio for groups listed in group.level.
#' @param categorical.weights A list of weighting factors for categorical covariates.
#' @param continuous.weights A list of weighting factors for continuous covariates.
#' @param start.number The subject index at which continuous covariate balancing begins.
#' @param num.categories Number of categories to split continuous variables into.
#' @param pct.deterministic Percent of subjects assigned more deterministically at trial end.
#' @param planned.sample.size Total planned sample size for the study.
#' @param pRA Vector of current response-adaptive probabilities.
#' @param tuning Sensitivity parameter for covariate balancing.
#' @param tuning2 Sensitivity parameter for response adaptation.
#' @export
#'
#' @examples
#' # 1. Prepare dummy data
#' set.seed(123)
#' data = data.frame("gender" = sample(c("female", "male"), 100, TRUE),
#'                   "age" = sample(c("<=50", ">50"), 100, TRUE),
#'                   "bmi" = rnorm(100, 25, 5))
#'
#' # 2. Define trial parameters
#' groups = c("Control", "Treatment_A", "Treatment_B")
#'
#' # 3. Define Response-Adaptive Probabilities (pRA)
#' # In a real trial, these come from your outcome model (e.g., postP.Bfun)
#' # For example, Treatment_A is performing better:
#' current_pRA = c(0.2, 0.5, 0.3)
#'
#' # 4. Run Randomization
#' # We randomize the first 20 subjects
#' data$group = NA
#'
#' randomized_groups = FUN.BCAR(
#'   data = data,
#'   group.var = "group",
#'   categorical.covariates = c("gender", "age"),
#'   continuous.covariates = c("bmi"),
#'   group.level = groups,
#'   pRA = current_pRA,
#'   tuning = 1,   # Balance covariates normally
#'   tuning2 = 2,  # Give extra weight to the response adaptation
#'   planned.sample.size = 100
#' )
#'
#' data$group = randomized_groups
#' print(table(data$group))
#'
#' @export
#'
#'
FUN.BCAR = function (data, group.var, categorical.covariates, continuous.covariates,
                     group.level, ratio, categorical.weights, continuous.weights,
                     start.number, num.categories, pct.deterministic, planned.sample.size,
                     pRA,
                     tuning,
                     tuning2)
{
  # Identify all covariate columns provided
  all_covs = c()
  if (!missing(categorical.covariates)) all_covs = c(all_covs, categorical.covariates)
  if (!missing(continuous.covariates)) all_covs = c(all_covs, continuous.covariates)

  if (length(all_covs) > 0) {
    # Find rows where EVERY covariate is NA
    # apply(..., 1, ...) checks row by row
    all_missing = apply(data[, all_covs, drop = FALSE], 1, function(x) all(is.na(x)))

    if (any(all_missing)) {
      data = data[!all_missing, ]
      message(paste("Removed", sum(all_missing), "rows where all covariates were missing."))
    }
  }
  # --- 1. Parameter Initialization & Missing Value Handling ---
  if (missing(planned.sample.size)) {
    planned.sample.size = nrow(data)
    print("Warning: planned.sample.size not defined. Randomization may be more deterministic.")
  }
  if (missing(num.categories)) { num.categories = 4 }
  if (missing(pct.deterministic)) { pct.deterministic = 0.05 }
  if (missing(start.number)) { start.number = 15 }
  if (missing(group.level)) { group.level = c("A", "B") }

  contin = PP = cPP = 1 # Flags/Placeholders for covariate probabilities
  if (missing(continuous.covariates)) {
    contin = 0
  } else {
    qk = rep(num.categories + 1, length(continuous.covariates))
  }

  if (missing(ratio)) { ratio = rep(1, length(group.level)) }
  if (missing(categorical.weights) & !missing(categorical.covariates)) {
    categorical.weights = rep(1, length(categorical.covariates))
  }
  if (missing(continuous.weights) & !missing(continuous.covariates)) {
    continuous.weights = rep(1, length(continuous.covariates))
  }

  if (missing(pRA)) { pRA = rep(1, length(group.level)) }
  # Tuning parameters default to 1 (neutral) if not provided
  if (missing(tuning)) { tuning = 0.5 }
  if (missing(tuning2)) { tuning2 = 1 }

  # Generate a random sequence to fill initial gaps if needed
  start.seq = rep(sample(group.level, length(group.level), replace = FALSE), 5)

  # --- 2. Data Preparation & Handling Existing Assignments ---
  if (missing(group.var)) {
    print("Please provide the name of the treatment group variable (e.g., group.var='group').")
  } else {
    # Check if the group variable already exists in the data
    if (any(names(data) %in% group.var)) {
      data$group = as.character(data[, group.var])
    } else {
      data$group = NA
    }

    #write.csv(data[order(data$random_group),], "H:/WFH/ACTION2/ACTION2/data.csv", row.names=FALSE)

    #datatest<<-
     # data=data[order(data$random_group),]

    # Identify the next subject needing randomization (start)
    non.missing = sum(!is.na(data$group) & data$group != "")
    start = non.missing + 1

    if (start <= nrow(data)) {
      # Ensure all group levels are represented in early assignments
      existing.groups = unique(data$group[1:non.missing])
      non.levels = group.level[which(!group.level %in% existing.groups)]
      non.levels = sample(non.levels)

      if (length(non.levels) != 0) {
        # Force assign empty levels to the next few subjects to ensure balance
        n.permutation = start:min(nrow(data), (start - 1 + length(non.levels)))
        data$group[n.permutation] = c(non.levels, start.seq)[1:length(n.permutation)]
      }

      non.missing = sum(!is.na(data$group) & data$group != "")
      start = non.missing + 1

      if (start <= nrow(data)) {
        # Reset future subjects to NA to prevent carry-over errors
        data$group[start:nrow(data)] = NA

        # --- 3. Main Randomization Loop ---
        for (i in start:nrow(data)) {

          # A. Categorical Covariate Balancing
          if (!missing(categorical.covariates)) {
            for (j in 1:length(categorical.covariates)) {
              NN.out = FNN.out(data, i, categorical.covariates[j],
                               ratio, categorical.weights[j], group.level = group.level)
              NN.out[[1]] = NN.out[[1]]/sum(NN.out[[1]])
              if (j == 1) { PP = NN.out[[1]] } else { PP = PP * NN.out[[1]] }
            }
          }

          # B. Continuous Covariate Balancing (starts after 'start.number' subjects)
          if (contin & i > start.number) {
            for (k in 1:length(continuous.covariates)) {
              cont = data[1:i, continuous.covariates[k]]
              # Convert continuous variable into categories based on quantiles
              ncc = stats::quantile(cont, seq(0, 1, length.out = qk[k]))
              ncc = ncc[-c(1, length(ncc))]
              data$ccont = 1
              for (l in 1:length(ncc)) { data$ccont[cont > ncc[l]] = (l + 1) }

              CNN.out = FNN.out(data, i, "ccont", ratio, continuous.weights[k], group.level = group.level)
              CNN.out[[1]] = CNN.out[[1]]/sum(CNN.out[[1]])
              if (CNN.out[[2]] == 1) { qk[k] = qk[k] + 1 } # Increase categories if needed
              if (k == 1) { cPP = CNN.out[[1]] } else { cPP = cPP * CNN.out[[1]] }
            }
          }

          # Combine covariate-adaptive probabilities (PPP)
          PPP = (PP/sum(PP)) * (cPP/sum(cPP))

          # --- 4. Response Adaptation & Final Assignment ---
          nc = floor((1 - pct.deterministic) * planned.sample.size)

          # Check if we are in the "burn-in" or regular phase vs. the end-of-study deterministic phase
          if (i > nc & (length(table(pRA)) == 1)) {
            # End of trial: Increase determinism to reach target sample size/balance
            pwhtrt = sample(group.level, 1, prob = PPP^(seq(2, 9, length.out = nrow(data) - nc)[i - nc]))
          }
          else {
            # Standard Adaptive Phase:
            # Combine Covariate Balancing (PPP) and Response Adaptation (pRA)
            # Use 'tuning' and 'tuning2' to weight the importance of each
            pwhtrt = sample(group.level, 1, prob = (PPP^tuning) * (pRA^tuning2))
          }
            eps = 1e-6
            u = tuning  * log(pmax(PPP, eps)) +
              tuning2 * log(pmax(pRA, eps))

            proba = exp(u) / sum(exp(u))

            pwhtrt = sample(group.level, 1, prob = proba)

            #print(paste0("tuning is ", tuning, "."))
            #print(paste0("tuning2 is ", tuning2, "."))
            print(paste0("Covariate biasing are ", round(PPP, 5), "."))
            print(paste0("Response biasing are ", round(pRA, 5), "."))
            print(paste0("Overall biasing are ", round((PPP^tuning) * (pRA^tuning2), 5), "."))

            print(paste0("Additive Overall biasing (used) are ", round(proba, 4), "."))

          # Assign the group to the current subject
          data$group[i] = pwhtrt
        }
      }
    }
  }
  return(data$group)
}
