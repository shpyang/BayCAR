#' Beta Distribution Integration Function
#'
#' Computes the product of Beta cumulative distribution functions multiplied by
#' a Beta density function for numerical integration. This is used in Bayesian
#' adaptive randomization to calculate posterior probabilities.
#'
#' @param x Numeric value at which to evaluate the integration function
#' @param ddata Numeric vector containing posterior parameters for the decision group(s)
#' @param cdata Numeric vector containing posterior parameters for the comparison group(s)
#' @param constant Numeric constant added to Beta distribution parameters to reflect
#'   the prior (e.g., 1 for Uniform, 0.5 for Jeffreys)
#'
#' @return The computed value of the integration function at point \code{x}
#'
#' @examples
#' \dontrun{
#' ddata <- c(10, 15)
#' cdata <- c(8, 12)
#' constant <- 1
#'
#' # Evaluate at a specific point
#' result <- B.int(x = 0.5, ddata = ddata, cdata = cdata, constant = constant)
#'
#' # Numerical integration example
#' integrate(f = B.int, lower = 0, upper = 1, ddata = ddata,
#'           cdata = cdata, constant = constant)
#' }
#' @export
#'
#'
B.int <- function(x, ddata, cdata, constant) {
  # Validate inputs
  if (length(ddata) == 0 || length(cdata) == 0) {
    stop("Both ddata and cdata must be non-empty vectors")
  }

  if (!is.numeric(x) || !is.numeric(ddata) || !is.numeric(cdata) || !is.numeric(constant)) {
    stop("All parameters must be numeric")
  }

  # Calculate the product of Beta CDFs for comparison groups
  cdf_product <- 1
  for (i in seq_along(cdata)) {
    # Calculate parameters for Beta distribution
    alpha_param <- sum(c(cdata, ddata)) - cdata[i] + constant
    beta_param <- cdata[i] + constant

    # Compute cumulative probability and multiply into product
    cdf_value <- stats::pbeta(x, alpha_param, beta_param)
    cdf_product <- cdf_product * cdf_value
  }

  # Calculate Beta density for decision group
  alpha_density <- sum(c(cdata, ddata)) - ddata + constant
  beta_density <- ddata + constant
  density_value <- stats::dbeta(x, alpha_density, beta_density)

  # Return the product of CDFs and density
  return(cdf_product * density_value)
}
