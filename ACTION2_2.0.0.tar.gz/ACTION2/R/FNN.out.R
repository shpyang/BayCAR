#' Covariate-Adaptive Randomization Probability Calculation
#'
#' Calculates assignment probabilities based on the current balance of a specific
#' categorical covariate.
#'
#' @param data A data frame containing covariates and group assignments
#' @param i Index of the current subject being randomized
#' @param covj Character string of the covariate name to be balanced
#' @param ratio Numeric vector for target assignment ratios
#' @param weights Numeric weight for the specific covariate
#' @param group.level Character vector of treatment group IDs
#'
#' @examples
#' # Create a dummy dataset with 10 existing subjects and 1 new subject
#' set.seed(42)
#' test_data <- data.frame(
#'   gender = c("M", "F", "M", "M", "F", "F", "M", "F", "M", "M", "F"),
#'   group = c("A", "A", "B", "A", "B", "B", "A", "B", "A", "B", NA)
#' )
#'
#' # Calculate probabilities for the 11th subject based on "gender"
#' result <- FNN.out(data = test_data, i = 11, covj = "gender",
#'                   ratio = c(1, 1), weights = 1, group.level = c("A", "B"))
#' @export
#'
#'
FNN.out = function(data, i, covj, ratio, weights, group.level) {

  # --- 1. Initialization and Defaults ---
  ink = 0  # A flag used to signal if the groups are already perfectly balanced (ink=1)

  if (missing(ratio)) { ratio = 1 }
  if (missing(weights)) { weights = 1 }

  # If group levels aren't provided, identify them from the existing data
  if (missing(group.level)) {
    group.level = sort(unique(data$group[!is.na(data$group)]))
  }

  # --- 2. Calculate Cross-Tabulation (The "Imbalance Table") ---
  # This creates a table showing the distribution of the covariate across treatment groups
  if (covj == "group") {
    # If the covariate itself is the 'group', just get the totals per group
    tg = t(table(data[, "group"]))
  } else {
    # Create a contingency table for the covariate 'covj' against treatment groups
    # Factor levels are forced to 'group.level' to ensure groups with 0 subjects are included
    tg = table(data[1:i, covj], factor(data$group[1:i], levels = group.level))
  }

  # Check if the difference between group sizes is less than 1 (Perfect Balance check)
  if (all(abs(tg[, 1] - tg[, 2]) < 1)) { ink = 1 }

  # --- 3. Focus on the Current Subject ---
  # Identify the specific covariate level of the subject currently being randomized
  gi = data[i, covj]

  # Extract the row from our table that matches the current subject's trait
  # e.g., "How many females are in Group A vs Group B?"
  frq0 = frq = t(tg[row.names(tg) == gi, ])

  # --- 4. Adjust for Ratios and Bayesian Processing ---
  if (all(frq == 0)) {
    # If no one with this covariate has been randomized yet, do nothing (all groups equal)
  } else {
    # Adjust frequencies based on the target randomization ratio
    frq = frq / ratio
    # Rescale frequencies to maintain the same total sum as the original counts
    frq = frq * sum(frq0) / sum(frq)
  }

  # Use the Bayesian posterior probability function to calculate the assignment probability
  # This typically favors the group that currently has fewer people with trait 'gi'
  g.out = postP.Bfun(frq)

  # Apply the importance weight to the calculated probability
  # A higher weight makes this covariate's balance more influential in the final decision
  g.out[[2]] = g.out[[2]]^weights

  # Return the probability vector and the balance flag
  return (list(g.out, ink))
}
