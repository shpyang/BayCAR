

api_url <- "https://redcap.adventhealth.com/api/"
api_token <- "2555D06723F4F5696ED304DC7B899586"

rfields=c("record_id", "random_age", "random_chemo_duration", "random_fluoropyrimidine",
          "random_chemo_started", "random_date", "random_group", "sex", "age", "dob")

efields=c("record_id", "age")
efields=c("record_id", "status")

# rand table
rraann= redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(rfields), verbose=FALSE)
rraa=as.data.frame(rraann$data)

rraa=rraa[!rraa$record_id%in%c("S05-01-TEST", "S05-02-TEST", "S05-03-TEST", "A00-00-TEST", "S05-01-TEST"),]
rraa$rDate=as.Date(rraa$random_date)
rraa1=rraa[substr(toupper(rraa$redcap_event_name ),1,3)=="PPT", c(1,5,6,7)]
#rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,9:14)]
rraa2=rraa[substr(toupper(rraa$redcap_event_name ),1,2)=="V2", c(1,8:13)]
rraa2=rraa2[!is.na(rraa2$random_group),]

rd=merge(rraa1, rraa2, by="record_id", all.y=TRUE)
rd$dur=rd$random_chemo_duration
#rd$rage=floor((rd$random_date-rd$dob)/365.25)
#rd$age=rd$rage
rd=rd[, -which(names(rd)%in%c("rage", "random_date"))]
#rd$agee= round(as.Date(rd$rDate)-as.Date(rd$dob))/365.25
rd=rd[!is.na(rd$rDate),]

rd[1:11,]



efields=c("record_id", "age")
efields=c("record_id", "chemo_status")

EEOS= redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(efields), verbose=FALSE)
EOS=as.data.frame(EEOS$data)

EOS[1:11,]

