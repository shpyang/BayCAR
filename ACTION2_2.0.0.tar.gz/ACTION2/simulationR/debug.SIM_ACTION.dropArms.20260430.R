
library("ACTION2")

# --- Setup ---
B <- 10
planned.sample.size <- 180
mu0=71; mu1=74; mu2=81; mu3=82; mu4=78
 # mu0=71; mu1=71; mu2=71; mu3=71; mu4=71
sd0=sd1=sd2=sd3=sd4= 18

premu <- c(mu0, mu1, mu2, mu3, mu4)
presd <- 1000
delay <- 0.4
delays <- floor(planned.sample.size/4 * delay)

group.level0 <- c("0", "A", "B", "C", "D")
updated.arms <- c("0", "A", "B")



Sys.time()


data <- data.frame("gender" = rep(NA, planned.sample.size), "age"=NA,
                   "Fluoro"=NA, "started"=NA, "dur"=NA, "group"=NA, "y"=NA,
                   stringsAsFactors = TRUE)

# Initial setup: Start with all 5 arms
current_group_level <- group.level0
n.runin <- 60 #round(planned.sample.size / 3)

# Initial batch enrollment (1 per arm)
n_init <- length(current_group_level)
data$gender[1:n_init] <- sample(c("female", "male"), n_init, TRUE, c(.6, .4))
data$age[1:n_init] <- sample(c("<=65", ">65"), n_init, TRUE, c(.7, .3))
data$Fluoro[1:n_init] =sample(c("Intravenous", "Oral"), n_init, TRUE, c(.6, .4))
data$started[1:n_init]=sample(c("No", "Yes"), n_init, TRUE, c(.4, .6))
data$dur[1:n_init] =sample(c("3m", "6m"), n_init, TRUE, c(.4, .6))
data$group[1:n_init] <- sample(current_group_level, n_init)


data$random_group=data$group

# Initialize pRA for first iterations (uniform)
pRA <- rep(1, length(current_group_level) - 1)
pRA <- pRA / sum(pRA)

# Sequential Enrollment Loop
for (si in (n_init + 1):planned.sample.size) {
  # 1. Generate Covariates
  data$gender[si] <- sample(c("female", "male"), 1, TRUE, c(.6, .4))
  data$age[si] <- sample(c("<=65", ">65"), 1, TRUE, c(.7, .3))
  data$Fluoro[si]  <- sample(c("Intravenous", "Oral"), 1, TRUE, c(.6, .4))
  data$started[si] <- sample(c("No", "Yes"), 1, TRUE, c(.4, .6))
  data$dur[si]     <- sample(c("3m", "6m"), 1, TRUE, c(.4, .6))

  # 2. Check for Arm Dropping
  if (si > n.runin) {
    current_group_level <- updated.arms;
    not.current_group_level=group.level0[!group.level0%in%updated.arms]

    bal_data <- data[!data$group %in% not.current_group_level, ]
    bal_data$group=factor(bal_data$group, levels=current_group_level)

    pRA <- rep(1, length(current_group_level) - 1)
    pRA <- pRA / sum(pRA)



    # 3. Calculate Response Adaptive Probabilities (pRA)
    tv=tdata_available <- data[!is.na(data$y) & !is.na(data$group), ]
    # Only calculate for active arms (excluding control '0')
    active_arms <- setdiff(current_group_level, "0")
    tdata_active <- tdata_available[tdata_available$group %in% active_arms, ]

    # Safety check: Need observations in active arms to update probabilities

    active_indices <- which(group.level0 %in% active_arms)
    # Map results to current active arms
    pratio <- postP.Nfun(data.frame(trt=tdata_active$group, y=tdata_active$y),
                         premu[active_indices], presd)

    pRA <- pratio / sum(pratio)


    # 4. Randomization Call (F.BayCARA)
    # Filter data to only include subjects belonging to current active groups for balancing
    not.current_group_level=group.level0[!group.level0%in%updated.arms]

    bal_data <- data[!data$group %in% not.current_group_level, ]
  }


  pRA_full <- c(max(pRA), pRA) # Mapping control probability to max of actives
  pRA_full <- pRA_full / sum(pRA_full)
  names(pRA_full)=current_group_level


  datainput=data[1:si,]
  if (si>n.runin) {datainput=bal_data}

  datainput$random_group=datainput$group

  res <- FUN.BCAR(datainput,
                  group.var = "group",

                  categorical.covariates = c("gender", "age", "Fluoro", "started", "dur"),
                  group.level = current_group_level,
                  planned.sample.size = planned.sample.size,
                  pRA=pRA_full, tuning = .25, tuning2 = 1)
  #print(pRA_full)
  data$group[si] <- res[max(which(!is.na(res)))]
  print(res[max(which(!is.na(res)))] )

  #if (si==40) {print(table(data$group))}
  # 5. Handle Delayed Outcomes
  obs_idx <- si - delays
  if (obs_idx > 0) {
    grp <- as.character(data$group[obs_idx])
    # Lookup mean/sd regardless of whether arm is still active
    m_idx <- match(grp, group.level0)
    data$y[obs_idx] <- rnorm(1, premu[m_idx], c(sd0, sd1, sd2, sd3, sd4)[m_idx])
  }


}

# Final outcome generation for all remaining subjects
missing_idx <- which(is.na(data$y))
for (idx in missing_idx) {
  grp <- as.character(data$group[idx])
  m_idx <- match(grp, group.level0)
  data$y[idx] <- rnorm(1, premu[m_idx], c(sd0, sd1, sd2, sd3, sd4)[m_idx])
}

# Final Analysis: Comparing Control to the best of A or B
final_inc <- c("0", "A", "B")
final_data <- data[data$group %in% final_inc, ]

# Identify the "best" active arm in the final set
agg_means <- aggregate(y ~ group, data = final_data[final_data$group != "0", ], mean)
best_arm <- as.character(agg_means$group[which.max(agg_means$y)])

# Final posterior calculation
analysis_set <- final_data[final_data$group %in% c("0", best_arm), ]
analysis_indices <- match(c("0", best_arm), group.level0)

ppRA <- postP.Nfun(data.frame(trt=analysis_set$group, y=analysis_set$y),
                   premu[analysis_indices], presd)

#                  ppRA # Return vector of probabilities
c(ppRA, as.vector(table(data$group)))


